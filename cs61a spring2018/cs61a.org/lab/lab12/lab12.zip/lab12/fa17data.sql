CREATE TABLE students_pt1 AS
   SELECT "11/7/2017 20:27:19" AS time, 7 AS number, "blue-green" AS color, "Choose this option instead." AS seven, "Feels by Calvin Harris" as song, "4/20" as date, "doggo" as pet, "Image 4" AS denero, "Image 1" AS hilfinger, 19 AS smallest UNION
   SELECT "11/7/2017 20:27:25" , 37        , "lavender"                  , "7"                          , "All I Want for Christmas"      , "7/13" , "puppy"                                             , "Image 4", "Image 2", 3      UNION
   SELECT "11/7/2017 20:27:44" , 50        , "blue"                      , "I'm a rebel"                , "Despacito"                     , "2/22" , "dog"                                               , "Image 4", "Image 4", 1000000  UNION
   SELECT "11/7/2017 20:27:48" , 5.859874482, "purple"                    , "I do what I want."          , "Nyan Cat"                      , "2/29" , "puppy-sized elephant"                              , "Image 4", "Image 3", 34     UNION
   SELECT "11/7/2017 20:27:48" , 69        , "pink"                      , "7"                          , "All I Want for Christmas"      , "12/23", "lion"                                              , "Image 1", "Image 4", 2      UNION
   SELECT "11/7/2017 20:28:03" , 24        , "yellow"                    , "7"                          , "Feels"                         , "2/24" , "lion"                                              , "Image 1", "Image 3", 37     UNION
   SELECT "11/7/2017 20:28:25" , 32        , "black"                     , "7"                          , "Despacito"                     , "9/7"  , "doggyy"                                            , "Image 5", "Image 5", 19     UNION
   SELECT "11/7/2017 20:28:39" , 13        , "blue"                      , "Choose this option instead.", "Nyan Cat"                      , "10/19", "cat"                                               , "Image 3", "Image 1", 15     UNION
   SELECT "11/7/2017 20:29:29" , 91        , "red"                       , "Choose this option instead.", "Nyan Cat"                      , "5/4"  , "cat"                                               , "Image 2", "Image 2", 1      UNION
   SELECT "11/7/2017 20:29:35" , 1         , "black"                     , "I do what I want."          , "Look What You Made Me Do"      , "6/23" , "dragon"                                            , "Image 4", "Image 2", 10     UNION
   SELECT "11/7/2017 20:29:42" , 34        , "black"                     , "I'm a rebel"                , "Nyan Cat"                      , "4/29" , "frog"                                              , "Image 5", "Image 4", 37     UNION
   SELECT "11/7/2017 20:29:42" , 48        , "pink"                      , "7"                          , "Despacito"                     , "9/3"  , "dog"                                               , "Image 4", "Image 1", 17     UNION
   SELECT "11/7/2017 20:29:48" , 8         , "green"                     , "Choose this option instead.", "All I Want for Christmas"      , "5/13" , "cat"                                               , "Image 3", "Image 1", 1      UNION
   SELECT "11/7/2017 20:30:06" , 15        , "pink"                      , "I do what I want."          , "All I Want for Christmas"      , "5/23" , "a giraffe"                                         , "Image 2", "Image 3", 1      UNION
   SELECT "11/7/2017 20:30:14" , 1.33769697, "yes"                       , "Choose this option instead.", "Nyan Cat"                      , "6/9"  , "liger"                                             , "Image 2", "Image 3", 25     UNION
   SELECT "11/7/2017 20:30:25" , 80        , "redl"                      , "7"                          , "Despacito"                     , "1/1"  , "white rhino"                                       , "Image 3", "Image 4", 1      UNION
   SELECT "11/7/2017 20:30:30" , 61        , "makememesgreatagain"       , "I'm a rebel"                , "Nyan Cat"                      , "11/11", "paul hilfinger"                                    , "Image 2", "Image 2", 1      UNION
   SELECT "11/7/2017 20:30:30" , 69        , "blue"                      , "Choose this option instead.", "Feels"                         , "8/24" , "snek"                                              , "Image 1", "Image 3", 24     UNION
   SELECT "11/7/2017 20:30:35" , 24        , "blue"                      , "YOLO!"                      , "Summer"                        , "7/31" , "t-rex"                                             , "Image 3", "Image 2", 1      UNION
   SELECT "11/7/2017 20:30:36" , 88        , "blue"                      , "You are not the boss of me!", "Havana"                        , "10/25", "cat"                                               , "Image 4", "Image 3", 3      UNION
   SELECT "11/7/2017 20:30:50" , 4         , "blue"                      , "I do what I want."          , "All I Want for Christmas"      , "2/4"  , "alaskan malamute "                                 , "Image 3", "Image 3", 12     UNION
   SELECT "11/7/2017 20:31:05" , 89        , "aqua"                      , "Choose this option instead.", "Nyan Cat"                      , "2/10" , "rock"                                              , "Image 3", "Image 2", 375    UNION
   SELECT "11/7/2017 20:31:06" , 27        , "blue"                      , "Choose this option instead.", "Havana"                        , "2/8"  , "dog"                                               , "Image 5", "Image 2", 23     UNION
   SELECT "11/7/2017 20:31:09" , 100       , "blue"                      , "7"                          , "All I Want for Christmas"      , "1/21" , "dog"                                               , "Image 4", "Image 2", 1      UNION
   SELECT "11/7/2017 20:31:25" , 17        , "pink"                      , "I do what I want."          , "Summer"                        , "1/31" , "lion"                                              , "Image 3", "Image 3", 1      UNION
   SELECT "11/7/2017 20:31:30" , 42        , "blue"                      , "I do what I want."          , "Havana"                        , "5/14" , "snow leopard"                                      , "Image 3", "Image 4", 23     UNION
   SELECT "11/7/2017 20:31:37" , 87        , "purple"                    , "7"                          , "Despacito"                     , "2/21" , "cat"                                               , "Image 5", "Image 4", 1      UNION
   SELECT "11/7/2017 20:31:38" , 6         , "orange"                    , "YOLO!"                      , "Summer"                        , "5/3"  , "dragon"                                            , "Image 2", "Image 1", 11     UNION
   SELECT "11/7/2017 20:31:41" , 5         , "blue"                      , "7"                          , "Despacito"                     , "8/18" , "cat"                                               , "Image 2", "Image 2", 102    UNION
   SELECT "11/7/2017 20:31:47" , 69        , "california gold"           , "7"                          , "Feels"                         , "12/25", "labrador retriever"                                , "Image 3", "Image 4", 5      UNION
   SELECT "11/7/2017 20:31:52" , 33        , "forest green"              , "Choose this option instead.", "All I Want for Christmas"      , "12/25", "dog"                                               , "Image 4", "Image 5", 23     UNION
   SELECT "11/7/2017 20:31:54" , 23        , "carrots"                   , "YOLO!"                      , "Nyan Cat"                      , "4/20" , "narwhal"                                           , "Image 3", "Image 3", 1      UNION
   SELECT "11/7/2017 20:31:54" , 15        , "blue"                      , "7"                          , "Look What You Made Me Do"      , "12/25", "dog"                                               , "Image 4", "Image 5", 27     UNION
   SELECT "11/7/2017 20:31:57" , 7         , "blue"                      , "7"                          , "Nyan Cat"                      , "2/1"  , "lion"                                              , "Image 3", "Image 1", 1      UNION
   SELECT "11/7/2017 20:32:09" , 17        , "powder blue"               , "Choose this option instead.", "Despacito"                     , "11/17", "dolphin"                                           , "Image 3", "Image 5", 39     UNION
   SELECT "11/7/2017 20:32:11" , 72        , "red"                       , "I do what I want."          , "All I Want for Christmas"      , "4/20" , "porcupine"                                         , "Image 4", "Image 1", 34     UNION
   SELECT "11/7/2017 20:32:12" , 8         , "black"                     , "7"                          , "Look What You Made Me Do"      , "1/1"  , "dragon"                                            , "Image 4", "Image 3", 1      UNION
   SELECT "11/7/2017 20:32:15" , 69        , "grey"                      , "I do what I want."          , "Summer"                        , "4/20" , "dog"                                               , "Image 2", "Image 3", 2      UNION
   SELECT "11/7/2017 20:32:21" , 1         , "red"                       , "7"                          , "Despacito"                     , "5/4"  , "tiger"                                             , "Image 2", "Image 2", 1      UNION
   SELECT "11/7/2017 20:32:25" , 28        , "blue"                      , "7"                          , "All I Want for Christmas"      , "1/1"  , "bearded dragon"                                    , "Image 4", "Image 4", 47     UNION
   SELECT "11/7/2017 20:32:25" , 25        , "blue"                      , "I do what I want."          , "Nyan Cat"                      , "6/23" , "sugar glider"                                      , "Image 4", "Image 3", 33     UNION
   SELECT "11/7/2017 20:32:37" , 88        , "red"                       , "YOLO!"                      , "All I Want for Christmas"      , "2/29" , "a dachshund "                                      , "Image 4", "Image 4", 1      UNION
   SELECT "11/7/2017 20:32:39" , 5         , "burgundy"                  , "I'm a rebel"                , "Havana"                        , "7/2"  , "wombat"                                            , "Image 1", "Image 4", 1      UNION
   SELECT "11/7/2017 20:32:44" , 27        , "violet"                    , "I do what I want."          , "Summer"                        , "10/31", "almighty god (not meant to be offensive,  just i'm a rebel)", "Image 3", "Image 3", 1      UNION
   SELECT "11/7/2017 20:32:45" , 69        , "purple"                    , "Choose this option instead.", "All I Want for Christmas"      , "8/2"  , "john denero"                                       , "Image 2", "Image 5", 1      UNION
   SELECT "11/7/2017 20:32:45" , 2         , "blue"                      , "YOLO!"                      , "Nyan Cat"                      , "2/29" , "cat!!!!"                                           , "Image 2", "Image 5", 17     UNION
   SELECT "11/7/2017 20:33:15" , 15        , "teal"                      , "I do what I want."          , "Summer"                        , "11/15", "owl"                                               , "Image 2", "Image 2", 1      UNION
   SELECT "11/7/2017 20:33:24" , 26        , "black"                     , "7"                          , "Despacito"                     , "8/24" , "kakapo"                                            , "Image 5", "Image 1", 11     UNION
   SELECT "11/7/2017 20:33:30" , 5         , "gold"                      , "I do what I want."          , "Nyan Cat"                      , "1/8"  , "dog"                                               , "Image 1", "Image 5", 246    UNION
   SELECT "11/7/2017 20:33:39" , 8         , "green"                     , "Choose this option instead.", "Look What You Made Me Do"      , "4/10" , "dog"                                               , "Image 3", "Image 4", 17     UNION
   SELECT "11/7/2017 20:33:39" , 21        , "blue"                      , "7"                          , "Despacito"                     , "12/25", "tiger"                                             , "Image 2", "Image 3", 2      UNION
   SELECT "11/7/2017 20:33:47" , 60        , "blue"                      , "7"                          , "All I Want for Christmas"      , "1/1"  , "dog"                                               , "Image 3", "Image 1", 1      UNION
   SELECT "11/7/2017 20:33:52" , 29        , "white"                     , "Choose this option instead.", "Look What You Made Me Do"      , "9/13" , "fox "                                              , "Image 4", "Image 1", 1      UNION
   SELECT "11/7/2017 20:34:16" , 17        , "#ffa353"                   , "Choose this option instead.", "Feels"                         , "6/24" , "anaconda "                                         , "Image 5", "Image 2", 17     UNION
   SELECT "11/7/2017 20:34:19" , 32        , "blue"                      , "I'm a rebel"                , "Despacito"                     , "3/3"  , "puppy"                                             , "Image 2", "Image 1", 6      UNION
   SELECT "11/7/2017 20:34:21" , 42        , "cerulean"                  , "Choose this option instead.", "Nyan Cat"                      , "1/1"  , "pangolin"                                          , "Image 5", "Image 5", 61     UNION
   SELECT "11/7/2017 20:34:35" , 72        , "gold"                      , "7"                          , "Despacito"                     , "5/15" , "a striped gray tabby cat!!"                        , "Image 4", "Image 1", 14     UNION
   SELECT "11/7/2017 20:34:37" , 5         , "purple"                    , "Choose this option instead.", "Havana"                        , "8/9"  , "seahorse"                                          , "Image 2", "Image 5", 1      UNION
   SELECT "11/7/2017 20:34:41" , 8         , "yellow"                    , "7"                          , "All I Want for Christmas"      , "12/13", "chinchilla"                                        , "Image 4", "Image 1", 23     UNION
   SELECT "11/7/2017 20:34:48" , 100       , "aquamarine"                , "Choose this option instead.", "Nyan Cat"                      , "2/3"  , "pufferfish"                                        , "Image 2", "Image 5", 999999999999  UNION
   SELECT "11/7/2017 20:34:54" , 15        , "black"                     , "7"                          , "All I Want for Christmas"      , "10/3" , "chinchilla"                                        , "Image 5", "Image 3", 13     UNION
   SELECT "11/7/2017 20:35:27" , 27        , "purple"                    , "Choose this option instead.", "All I Want for Christmas"      , "3/9"  , "hercules beetle"                                   , "Image 5", "Image 1", 18     UNION
   SELECT "11/7/2017 20:35:38" , 33        , "black"                     , "Choose this option instead.", "All I Want for Christmas"      , "11/11", "corgi"                                             , "Image 2", "Image 1", 69     UNION
   SELECT "11/7/2017 20:35:44" , 69        , "dick"                      , "7"                          , "Nyan Cat"                      , "9/25" , "memes"                                             , "Image 5", "Image 3", 18     UNION
   SELECT "11/7/2017 20:36:06" , 5         , "blue"                      , "7"                          , "Nyan Cat"                      , "10/1" , "dog"                                               , "Image 1", "Image 1", 1      UNION
   SELECT "11/7/2017 20:36:19" , 55        , "gray"                      , "7"                          , "Feels"                         , "9/12" , "monkey"                                            , "Image 5", "Image 3", 23     UNION
   SELECT "11/7/2017 20:36:24" , 23        , "blue"                      , "7"                          , "Havana"                        , "6/8"  , "dog"                                               , "Image 4", "Image 1", 29     UNION
   SELECT "11/7/2017 20:36:36" , 69        , "blue"                      , "7"                          , "All I Want for Christmas"      , "4/20" , "rhinocerous"                                       , "Image 4", "Image 3", 64     UNION
   SELECT "11/7/2017 20:36:38" , 8         , "pink"                      , "Choose this option instead.", "Look What You Made Me Do"      , "11/12", "dog"                                               , "Image 3", "Image 2", 1      UNION
   SELECT "11/7/2017 20:36:43" , 70        , "sanchit"                   , "Choose this option instead.", "Summer"                        , "8/10" , "sanchit"                                           , "Image 5", "Image 2", 23     UNION
   SELECT "11/7/2017 20:37:04" , 2         , "teal"                      , "Choose this option instead.", "All I Want for Christmas"      , "5/25" , "dog"                                               , "Image 4", "Image 4", 15     UNION
   SELECT "11/7/2017 20:37:05" , 77        , "green"                     , "I do what I want."          , "Havana"                        , "8/30" , "unicorn"                                           , "Image 1", "Image 1", 65     UNION
   SELECT "11/7/2017 20:37:13" , 25        , "blue"                      , "7"                          , "Feels"                         , "1/2"  , "berkeley squirrel"                                 , "Image 1", "Image 4", 99     UNION
   SELECT "11/7/2017 20:37:32" , 16        , "mint"                      , "Choose this option instead.", "Feels"                         , "2/29" , "a dugong"                                          , "Image 5", "Image 1", 1      UNION
   SELECT "11/7/2017 20:37:51" , 64        , "blue"                      , "Choose this option instead.", "Nyan Cat"                      , "6/28" , "denero"                                            , "Image 1", "Image 2", 23     UNION
   SELECT "11/7/2017 20:37:59" , 1         , "blue"                      , "Choose this option instead.", "Despacito"                     , "11/11", "squirrel"                                          , "Image 1", "Image 1", 65     UNION
   SELECT "11/7/2017 20:38:32" , 17        , "turquoise"                 , "7"                          , "Look What You Made Me Do"      , "12/1" , "ocelot"                                            , "Image 4", "Image 5", 1      UNION
   SELECT "11/7/2017 20:38:42" , 11        , "white"                     , "7"                          , "Look What You Made Me Do"      , "5/1"  , "leopard"                                           , "Image 3", "Image 3", 1      UNION
   SELECT "11/7/2017 20:38:50" , 88        , "purple"                    , "7"                          , "Despacito"                     , "10/24", "snake"                                             , "Image 3", "Image 3", 0      UNION
   SELECT "11/7/2017 20:39:04" , 2         , "rainbow"                   , "7"                          , "Look What You Made Me Do"      , "5/24" , "cat"                                               , "Image 5", "Image 2", 1      UNION
   SELECT "11/7/2017 20:39:52" , 96        , "blue"                      , "I do what I want."          , "Havana"                        , "6/12" , "cat"                                               , "Image 2", "Image 1", 23     UNION
   SELECT "11/7/2017 20:40:07" , 6         , "blue"                      , "7"                          , "All I Want for Christmas"      , "1/1"  , "chinchilla "                                       , "Image 4", "Image 1", 1      UNION
   SELECT "11/7/2017 20:40:08" , 1         , "green"                     , "7"                          , "Despacito"                     , "9/11" , "dog"                                               , "Image 4", "Image 1", 1      UNION
   SELECT "11/7/2017 20:40:33" , 64        , "blue"                      , "7"                          , "Look What You Made Me Do"      , "1/1"  , "to be fair it takes a really high iq to understand pets", "Image 3", "Image 4", 26     UNION
   SELECT "11/7/2017 20:40:39" , 2         , "maroon"                    , "Choose this option instead.", "Despacito"                     , "8/6"  , "seahorse"                                          , "Image 5", "Image 3", 1      UNION
   SELECT "11/7/2017 20:40:53" , 37        , "blue "                     , "I do what I want."          , "All I Want for Christmas"      , "11/7" , "doggo "                                            , "Image 4", "Image 3", 1      UNION
   SELECT "11/7/2017 20:40:55" , 9         , "blue"                      , "Choose this option instead.", "Nyan Cat"                      , "5/28" , "goliath birdeater"                                 , "Image 4", "Image 2", 34     UNION
   SELECT "11/7/2017 20:41:21" , 69        , "purple"                    , "Choose this option instead.", "All I Want for Christmas"      , "9/27" , "moose"                                             , "Image 2", "Image 1", 193    UNION
   SELECT "11/7/2017 20:41:47" , 9         , "pink"                      , "YOLO!"                      , "Feels"                         , "6/8"  , "dog"                                               , "Image 4", "Image 1", 3      UNION
   SELECT "11/7/2017 20:41:57" , 56        , "blue"                      , "Choose this option instead.", "Havana"                        , "12/15", "husky"                                             , "Image 3", "Image 2", 1      UNION
   SELECT "11/7/2017 20:42:39" , 4         , "cobalt"                    , "7"                          , "Nyan Cat"                      , "2/18" , "cat"                                               , "Image 4", "Image 2", 1      UNION
   SELECT "11/7/2017 20:43:12" , 17        , "blue"                      , "7"                          , "Nyan Cat"                      , "2/29" , "snow leopard"                                      , "Image 2", "Image 2", 6      UNION
   SELECT "11/7/2017 20:43:12" , 27        , "#d0f0c0"                   , "Choose this option instead.", "Nyan Cat"                      , "1/31" , "peach-faced lovebird"                              , "Image 4", "Image 2", 2      UNION
   SELECT "11/7/2017 20:43:12" , 22        , "green "                    , "7"                          , "Feels"                         , "12/26", "otter "                                            , "Image 1", "Image 5", 32     UNION
   SELECT "11/7/2017 20:43:21" , 11        , "green"                     , "YOLO!"                      , "Despacito"                     , "10/18", "panda"                                             , "Image 2", "Image 4", 105    UNION
   SELECT "11/7/2017 20:44:39" , 69        , "pink"                      , "I do what I want."          , "Despacito"                     , "6/9"  , "rabbits"                                           , "Image 5", "Image 5", 69     UNION
   SELECT "11/7/2017 20:45:08" , 7         , "turquoise"                 , "7"                          , "Feels"                         , "12/7" , "pug"                                               , "Image 3", "Image 3", 1      UNION
   SELECT "11/7/2017 20:45:09" , 7         , "blue"                      , "7"                          , "Summer"                        , "3/27" , "corgi"                                             , "Image 5", "Image 3", 19     UNION
   SELECT "11/7/2017 20:45:41" , 69        , "black"                     , "Choose this option instead.", "Look What You Made Me Do"      , "8/15" , "dragon"                                            , "Image 5", "Image 1", 1      UNION
   SELECT "11/7/2017 20:46:23" , 4         , "red"                       , "7"                          , "Look What You Made Me Do"      , "6/27" , "penguin"                                           , "Image 2", "Image 1", 16     UNION
   SELECT "11/7/2017 20:46:45" , 46        , "46"                        , "7"                          , "Nyan Cat"                      , "2/29" , "john denero"                                       , "Image 2", "Image 2", 85     UNION
   SELECT "11/7/2017 20:47:21" , 88        , "blue"                      , "7"                          , "Havana"                        , "2/29" , "panda"                                             , "Image 4", "Image 2", 13     UNION
   SELECT "11/7/2017 20:47:55" , 29        , "blue"                      , "7"                          , "Havana"                        , "6/29" , "elephant"                                          , "Image 1", "Image 1", 1      UNION
   SELECT "11/7/2017 20:48:03" , 88        , "pink"                      , "You are not the boss of me!", "Havana"                        , "7/4"  , "whale"                                             , "Image 2", "Image 2", 53     UNION
   SELECT "11/7/2017 20:48:08" , 87        , "blue"                      , "Choose this option instead.", "Summer"                        , "2/29" , "yes"                                               , "Image 2", "Image 2", 23     UNION
   SELECT "11/7/2017 20:48:13" , 21        , "black"                     , "Choose this option instead.", "Havana"                        , "1/1"  , "cat"                                               , "Image 2", "Image 2", 41     UNION
   SELECT "11/7/2017 20:48:27" , 7         , "7"                         , "7"                          , "Feels"                         , "7/7"  , "7"                                                 , "Image 5", "Image 5", 7      UNION
   SELECT "11/7/2017 20:49:04" , 7         , "salmon"                    , "You are not the boss of me!", "All I Want for Christmas"      , "9/24" , "hippo"                                             , "Image 4", "Image 2", 2      UNION
   SELECT "11/7/2017 20:49:30" , 13        , "pink"                      , "7"                          , "Feels"                         , "5/19" , "pug"                                               , "Image 2", "Image 1", 32     UNION
   SELECT "11/7/2017 20:49:40" , 54        , "teal"                      , "I do what I want."          , "All I Want for Christmas"      , "2/10" , "panda"                                             , "Image 5", "Image 2", 24     UNION
   SELECT "11/7/2017 20:50:37" , 11        , "blue "                     , "YOLO!"                      , "Despacito"                     , "2/14" , "polar bear "                                       , "Image 3", "Image 3", 1      UNION
   SELECT "11/7/2017 20:50:46" , 77        , "blue"                      , "You are not the boss of me!", "Nyan Cat"                      , "1/11" , "dog"                                               , "Image 3", "Image 4", 39     UNION
   SELECT "11/7/2017 20:51:26" , 17        , "blue"                      , "I'm a rebel"                , "Despacito"                     , "12/27", "bunny"                                             , "Image 3", "Image 4", 26     UNION
   SELECT "11/7/2017 20:51:30" , 64        , "magenta"                   , "7"                          , "Havana"                        , "12/1" , "a small alligator "                                , "Image 4", "Image 1", 43     UNION
   SELECT "11/7/2017 20:51:59" , 5         , "blue"                      , "7"                          , "Havana"                        , "11/10", "dragon"                                            , "Image 5", "Image 2", 1      UNION
   SELECT "11/7/2017 20:52:10" , 69        , "dank green"                , "7"                          , "Havana"                        , "4/20" , "dog"                                               , "Image 1", "Image 3", 61     UNION
   SELECT "11/7/2017 20:52:11" , 13        , "red"                       , "7"                          , "Despacito"                     , "7/1"  , "dog"                                               , "Image 1", "Image 5", 1      UNION
   SELECT "11/7/2017 20:52:23" , 58        , "58"                        , "Choose this option instead.", "Feels"                         , "2/29" , "jooooooooooooooooooooooooooooooooooooooohn cenaa"  , "Image 5", "Image 2", 4      UNION
   SELECT "11/7/2017 20:52:29" , 69        , "pink"                      , "I'm a rebel"                , "Despacito"                     , "4/20" , "pig"                                               , "Image 1", "Image 3", 69     UNION
   SELECT "11/7/2017 20:53:16" , 8         , "blue"                      , "7"                          , "Nyan Cat"                      , "10/8" , "monkey"                                            , "Image 2", "Image 2", 1      UNION
   SELECT "11/7/2017 20:53:26" , 49        , "turquoise "                , "I do what I want."          , "All I Want for Christmas"      , "4/21" , "diagla"                                            , "Image 3", "Image 3", 28     UNION
   SELECT "11/7/2017 20:53:28" , 12        , "green"                     , "I'm a rebel"                , "Feels"                         , "9/12" , "butterfly "                                        , "Image 4", "Image 3", 1      UNION
   SELECT "11/7/2017 20:53:30" , 15        , "green"                     , "7"                          , "All I Want for Christmas"      , "5/5"  , "tiger"                                             , "Image 3", "Image 1", 23     UNION
   SELECT "11/7/2017 20:53:57" , 29        , "4.0gpa"                    , "7"                          , "All I Want for Christmas"      , "12/29", "a 4.0 gpa"                                         , "Image 4", "Image 4", 4      UNION
   SELECT "11/7/2017 20:54:01" , 42        , "green"                     , "7"                          , "Feels"                         , "5/7"  , "husky"                                             , "Image 4", "Image 2", 19     UNION
   SELECT "11/7/2017 20:54:05" , 13        , "blue"                      , "Choose this option instead.", "Look What You Made Me Do"      , "5/10" , "denero"                                            , "Image 1", "Image 2", 13     UNION
   SELECT "11/7/2017 20:54:52" , 13        , "purple"                    , "7"                          , "Summer"                        , "7/13" , "bunny"                                             , "Image 1", "Image 5", 11     UNION
   SELECT "11/7/2017 20:55:10" , 50        , "blue"                      , "YOLO!"                      , "Despacito"                     , "12/31", "dog"                                               , "Image 3", "Image 4", 11     UNION
   SELECT "11/7/2017 20:55:18" , 23.3      , "blue"                      , "Choose this option instead.", "Look What You Made Me Do"      , "6/16" , "squirrel"                                          , "Image 3", "Image 2", 10     UNION
   SELECT "11/7/2017 20:55:21" , 69        , "blue"                      , "Choose this option instead.", "Nyan Cat"                      , "1/1"  , "squid"                                             , "Image 2", "Image 5", 40     UNION
   SELECT "11/7/2017 20:55:25" , 42        , "blue"                      , "Choose this option instead.", "Summer"                        , "4/1"  , "dolphin"                                           , "Image 4", "Image 1", 25     UNION
   SELECT "11/7/2017 20:55:29" , 69        , "white"                     , "7"                          , "All I Want for Christmas"      , "4/20" , "sloth"                                             , "Image 1", "Image 4", 21     UNION
   SELECT "11/7/2017 20:55:35" , 77        , "blue"                      , "You are not the boss of me!", "Havana"                        , "12/25", "golden retriever "                                 , "Image 2", "Image 2", 1      UNION
   SELECT "11/7/2017 20:56:17" , 30        , "gold"                      , "I do what I want."          , "All I Want for Christmas"      , "12/15", "dik-dik"                                           , "Image 2", "Image 2", 37     UNION
   SELECT "11/7/2017 20:56:27" , 69        , "blue"                      , "You are not the boss of me!", "Look What You Made Me Do"      , "5/14" , "jellyfish"                                         , "Image 4", "Image 3", 31     UNION
   SELECT "11/7/2017 20:56:50" , 72        , "blood"                     , "Choose this option instead.", "Feels"                         , "4/20" , "harpy eagle"                                       , "Image 4", "Image 3", 23     UNION
   SELECT "11/7/2017 20:56:57" , 12        , "blue"                      , "7"                          , "Feels"                         , "9/22" , "eagle"                                             , "Image 1", "Image 3", 3      UNION
   SELECT "11/7/2017 20:57:09" , 61        , "blue"                      , "I do what I want."          , "All I Want for Christmas"      , "10/25", "tiger"                                             , "Image 4", "Image 4", 19     UNION
   SELECT "11/7/2017 20:57:21" , 33        , "blue"                      , "I do what I want."          , "Feels"                         , "5/23" , "lynx"                                              , "Image 1", "Image 5", 78     UNION
   SELECT "11/7/2017 20:57:26" , 69        , "blue"                      , "7"                          , "Feels"                         , "9/19" , "betta fish"                                        , "Image 5", "Image 4", 1      UNION
   SELECT "11/7/2017 20:58:24" , 7         , "cream"                     , "7"                          , "All I Want for Christmas"      , "2/14" , "chinchilla"                                        , "Image 5", "Image 1", 1      UNION
   SELECT "11/7/2017 20:58:28" , 7         , "red"                       , "7"                          , "Despacito"                     , "11/11", "a dog"                                             , "Image 5", "Image 1", 2      UNION
   SELECT "11/7/2017 20:58:47" , 61        , "grey "                     , "YOLO!"                      , "Summer"                        , "12/25", "penguin"                                           , "Image 3", "Image 5", 13     UNION
   SELECT "11/7/2017 20:58:50" , 21        , "black"                     , "I do what I want."          , "All I Want for Christmas"      , "3/28" , "dog"                                               , "Image 5", "Image 1", 1      UNION
   SELECT "11/7/2017 20:59:02" , 67        , "teal"                      , "7"                          , "Look What You Made Me Do"      , "5/20" , "panda bear"                                        , "Image 4", "Image 3", 8      UNION
   SELECT "11/7/2017 20:59:35" , 18        , "blue"                      , "7"                          , "Summer"                        , "2/18" , "cat"                                               , "Image 3", "Image 5", 1      UNION
   SELECT "11/7/2017 20:59:51" , 23        , "red"                       , "7"                          , "Look What You Made Me Do"      , "10/4" , "dog"                                               , "Image 3", "Image 1", 1      UNION
   SELECT "11/7/2017 21:00:11" , 33        , "black"                     , "I do what I want."          , "Summer"                        , "7/30" , "hedgehog"                                          , "Image 2", "Image 5", 12     UNION
   SELECT "11/7/2017 21:00:20" , 3         , "fuchsia"                   , "I do what I want."          , "Nyan Cat"                      , "7/30" , ";drop table responses"                             , "Image 4", "Image 2", 34     UNION
   SELECT "11/7/2017 21:01:24" , 7         , "electric blue"             , "7"                          , "All I Want for Christmas"      , "11/11", "dragon"                                            , "Image 3", "Image 4", 17     UNION
   SELECT "11/7/2017 21:01:59" , 69        , "weed"                      , "Choose this option instead.", "All I Want for Christmas"      , "4/20" , "blue whale"                                        , "Image 3", "Image 1", 1      UNION
   SELECT "11/7/2017 21:02:06" , 5         , "gray"                      , "7"                          , "All I Want for Christmas"      , "4/1"  , "blue whale. or a dik dik. why not both?"           , "Image 4", "Image 2", 8      UNION
   SELECT "11/7/2017 21:02:26" , 7         , "yellow"                    , "Choose this option instead.", "Despacito"                     , "7/4"  , "axolotl"                                           , "Image 4", "Image 4", 13     UNION
   SELECT "11/7/2017 21:03:00" , 76        , "blue"                      , "7"                          , "Feels"                         , "1/1"  , "fish sticks"                                       , "Image 1", "Image 4", 16     UNION
   SELECT "11/7/2017 21:03:21" , 1         , "blue"                      , "I do what I want."          , "Despacito"                     , "11/12", "cat"                                               , "Image 1", "Image 2", 25     UNION
   SELECT "11/7/2017 21:03:28" , 69        , "purple"                    , "Choose this option instead.", "Havana"                        , "4/20" , "john denero"                                       , "Image 1", "Image 4", 46     UNION
   SELECT "11/7/2017 21:03:32" , 69        , "white"                     , "I do what I want."          , "All I Want for Christmas"      , "6/9"  , "capybara"                                          , "Image 4", "Image 1", 69     UNION
   SELECT "11/7/2017 21:03:43" , 7         , "blue"                      , "YOLO!"                      , "All I Want for Christmas"      , "12/16", "dog"                                               , "Image 1", "Image 3", 31     UNION
   SELECT "11/7/2017 21:04:06" , 30        , "blue"                      , "7"                          , "Havana"                        , "6/29" , "lion"                                              , "Image 1", "Image 3", 11     UNION
   SELECT "11/7/2017 21:04:41" , 27        , "blue"                      , "I do what I want."          , "Feels"                         , "10/3" , "great white shark"                                 , "Image 1", "Image 4", 1      UNION
   SELECT "11/7/2017 21:04:57" , 19        , "all the colors"            , "7"                          , "Summer"                        , "8/19" , "panther"                                           , "Image 4", "Image 1", 19     UNION
   SELECT "11/7/2017 21:04:58" , 2         , "2"                         , "7"                          , "Nyan Cat"                      , "2/2"  , "2"                                                 , "Image 2", "Image 2", 2      UNION
   SELECT "11/7/2017 21:05:05" , 21        , "blue"                      , "7"                          , "Look What You Made Me Do"      , "12/24", "panda"                                             , "Image 3", "Image 5", 313    UNION
   SELECT "11/7/2017 21:05:05" , 7         , "blue"                      , "Choose this option instead.", "Feels"                         , "11/16", "red panda"                                         , "Image 3", "Image 4", 31     UNION
   SELECT "11/7/2017 21:05:11" , 69        , "red"                       , "You are not the boss of me!", "All I Want for Christmas"      , "10/13", "john denero"                                       , "Image 2", "Image 5", 23     UNION
   SELECT "11/7/2017 21:05:21" , 64        , "green"                     , "I do what I want."          , "All I Want for Christmas"      , "12/29", "red panda"                                         , "Image 2", "Image 3", 82     UNION
   SELECT "11/7/2017 21:05:39" , 31        , "blue"                      , "7"                          , "All I Want for Christmas"      , "1/2"  , "otter"                                             , "Image 2", "Image 5", 3      UNION
   SELECT "11/7/2017 21:06:22" , 69        , "green"                     , "7"                          , "Despacito"                     , "10/14", "none"                                              , "Image 3", "Image 1", 98     UNION
   SELECT "11/7/2017 21:06:33" , 1         , "i'm colorblind "           , "7"                          , "Nyan Cat"                      , "10/11", "dog"                                               , "Image 1", "Image 2", 1      UNION
   SELECT "11/7/2017 21:06:37" , 17        , "blue"                      , "7"                          , "Havana"                        , "7/17" , "white tiger"                                       , "Image 3", "Image 3", 11     UNION
   SELECT "11/7/2017 21:07:00" , 31        , "purple"                    , "YOLO!"                      , "Look What You Made Me Do"      , "3/14" , "penguin"                                           , "Image 2", "Image 4", 89     UNION
   SELECT "11/7/2017 21:07:23" , 28        , "yellow"                    , "7"                          , "Feels"                         , "12/25", "panda"                                             , "Image 1", "Image 1", 89     UNION
   SELECT "11/7/2017 21:07:48" , 17        , "black"                     , "7"                          , "Havana"                        , "12/12", "dog"                                               , "Image 5", "Image 4", 1      UNION
   SELECT "11/7/2017 21:08:12" , 7         , "blue"                      , "7"                          , "Despacito"                     , "1/28" , "liger"                                             , "Image 3", "Image 4", 20     UNION
   SELECT "11/7/2017 21:08:13" , 1         , "blue"                      , "You are not the boss of me!", "Havana"                        , "2/29" , "pig "                                              , "Image 3", "Image 1", 1      UNION
   SELECT "11/7/2017 21:08:49" , 98        , "black"                     , "7"                          , "All I Want for Christmas"      , "9/8"  , "a tiger."                                          , "Image 1", "Image 1", 9      UNION
   SELECT "11/7/2017 21:09:52" , 25        , "blue"                      , "Choose this option instead.", "All I Want for Christmas"      , "12/25", "one of everything"                                 , "Image 4", "Image 1", 9      UNION
   SELECT "11/7/2017 21:11:10" , 93        , "black"                     , "I do what I want."          , "Despacito"                     , "9/30" , "kitty!"                                            , "Image 4", "Image 1", 1      UNION
   SELECT "11/7/2017 21:11:58" , 2         , "blue"                      , "7"                          , "Summer"                        , "3/6"  , "dog"                                               , "Image 4", "Image 1", 1      UNION
   SELECT "11/7/2017 21:12:33" , 68        , "purple"                    , "7"                          , "Look What You Made Me Do"      , "9/3"  , "dolphin"                                           , "Image 4", "Image 1", 11     UNION
   SELECT "11/7/2017 21:13:05" , 26        , "cornflower blue"           , "I'm a rebel"                , "Feels"                         , "11/22", "sloth"                                             , "Image 3", "Image 1", 1      UNION
   SELECT "11/7/2017 21:13:13" , 100       , "blue"                      , "Choose this option instead.", "Havana"                        , "11/28", "eagle"                                             , "Image 4", "Image 1", 121    UNION
   SELECT "11/7/2017 21:13:20" , 13        , "green"                     , "7"                          , "Despacito"                     , "4/25" , "llama"                                             , "Image 1", "Image 2", 1      UNION
   SELECT "11/7/2017 21:14:24" , 83        , "maroon"                    , "7"                          , "Feels"                         , "11/17", "tiger"                                             , "Image 4", "Image 4", 6      UNION
   SELECT "11/7/2017 21:15:37" , 42        , "you must construct additional pylons", "I do what I want."          , "All I Want for Christmas"      , "4/20" , "john denero"                                       , "Image 3", "Image 4", 0.01   UNION
   SELECT "11/7/2017 21:15:38" , 18        , "silver"                    , "7"                          , "Feels"                         , "8/26" , "lion"                                              , "Image 2", "Image 4", 1      UNION
   SELECT "11/7/2017 21:17:26" , 1         , "yellow"                    , "Choose this option instead.", "Look What You Made Me Do"      , "11/23", "corgi"                                             , "Image 5", "Image 3", 16     UNION
   SELECT "11/7/2017 21:19:07" , 32        , "#001f3f"                   , "7"                          , "Havana"                        , "9/30" , "quokka"                                            , "Image 4", "Image 2", 10     UNION
   SELECT "11/7/2017 21:19:17" , 2         , "black"                     , "7"                          , "Despacito"                     , "10/31", "a (pack of) fancy rat(s)"                          , "Image 3", "Image 5", 7      UNION
   SELECT "11/7/2017 21:19:42" , 10        , "red"                       , "7"                          , "Despacito"                     , "3/26" , "my dog"                                            , "Image 3", "Image 2", 41     UNION
   SELECT "11/7/2017 21:20:52" , 99        , "blue!"                     , "Choose this option instead.", "All I Want for Christmas"      , "3/1"  , "a mini elephant that can talk"                     , "Image 5", "Image 5", 1      UNION
   SELECT "11/7/2017 21:21:27" , 17        , "turquoise"                 , "7"                          , "All I Want for Christmas"      , "2/29" , "dog"                                               , "Image 1", "Image 1", 6      UNION
   SELECT "11/7/2017 21:21:30" , 72        , "cerulean "                 , "7"                          , "All I Want for Christmas"      , "4/8"  , "small cat"                                         , "Image 1", "Image 5", 11     UNION
   SELECT "11/7/2017 21:21:43" , 77        , "royal blue, the color of the early night or before dawn", "Choose this option instead.", "Nyan Cat"                      , "11/12", "tardigrade"                                        , "Image 5", "Image 3", 89     UNION
   SELECT "11/7/2017 21:22:02" , 33        , "red"                       , "I'm a rebel"                , "Summer"                        , "12/25", "shark"                                             , "Image 2", "Image 3", 5      UNION
   SELECT "11/7/2017 21:22:03" , 19        , "black"                     , "7"                          , "All I Want for Christmas"      , "2/19" , "dog"                                               , "Image 1", "Image 5", 1      UNION
   SELECT "11/7/2017 21:22:14" , 69        , "purple"                    , "7"                          , "Despacito"                     , "4/15" , "dragon"                                            , "Image 5", "Image 2", 6      UNION
   SELECT "11/7/2017 21:22:37" , 7         , "gold"                      , "Choose this option instead.", "All I Want for Christmas"      , "7/31" , "pterosaur"                                         , "Image 4", "Image 2", 11     UNION
   SELECT "11/7/2017 21:22:59" , 69        , "blue"                      , "YOLO!"                      , "Feels"                         , "12/13", "a dog"                                             , "Image 5", "Image 2", 1      UNION
   SELECT "11/7/2017 21:23:42" , 8         , "pink"                      , "7"                          , "Despacito"                     , "8/8"  , "dolphin"                                           , "Image 4", "Image 4", 1      UNION
   SELECT "11/7/2017 21:24:24" , 73        , "turquoise"                 , "7"                          , "Nyan Cat"                      , "9/2"  , "turtle"                                            , "Image 1", "Image 4", 1      UNION
   SELECT "11/7/2017 21:25:40" , 69        , "orange"                    , "I do what I want."          , "Nyan Cat"                      , "4/20" , "cat"                                               , "Image 1", "Image 3", 43     UNION
   SELECT "11/7/2017 21:26:11" , 61        , "aquamarine "               , "7"                          , "Feels"                         , "10/31", "phoenix "                                          , "Image 5", "Image 5", 1      UNION
   SELECT "11/7/2017 21:26:53" , 5         , "dark blue"                 , "7"                          , "Look What You Made Me Do"      , "10/20", "bunny"                                             , "Image 4", "Image 4", 3      UNION
   SELECT "11/7/2017 21:27:31" , 13        , "blue"                      , "Choose this option instead.", "All I Want for Christmas"      , "1/13" , "a doge that borks "                                , "Image 4", "Image 1", 7      UNION
   SELECT "11/7/2017 21:27:46" , 69        , "blue"                      , "7"                          , "Feels"                         , "3/10" , "tiny elephant"                                     , "Image 5", "Image 1", 58     UNION
   SELECT "11/7/2017 21:28:04" , 3.14      , "light purple"              , "YOLO!"                      , "All I Want for Christmas"      , "11/6" , "a dog"                                             , "Image 3", "Image 3", 99999999999999  UNION
   SELECT "11/7/2017 21:29:41" , 67        , "white"                     , "I'm a rebel"                , "Havana"                        , "1/6"  , "lion"                                              , "Image 5", "Image 3", 27     UNION
   SELECT "11/7/2017 21:33:07" , 27        , "crimson red"               , "I do what I want."          , "Havana"                        , "3/14" , "dolphin"                                           , "Image 3", "Image 5", 31     UNION
   SELECT "11/7/2017 21:33:08" , 69        , "death"                     , "I do what I want."          , "All I Want for Christmas"      , "1/23" , "lion"                                              , "Image 4", "Image 4", 97;
   

CREATE TABLE students_pt2 AS
SELECT "11/7/2017 21:34:38" AS time, 69 AS number , "pink" AS color , "7" AS seven, "All I Want for Christmas" AS song, "5/19" AS date, "ur mum" AS pet, "Image 1" AS denero, "Image 2" AS hilfinger, 6969696969696969696969696969696969696969696969696969696969696969696969696969696 AS smallest  UNION
   SELECT "11/7/2017 21:34:45" , 24        , "blue"                      , "7"                          , "Feels"                         , "4/24" , "penguin"                                           , "Image 1", "Image 2", 2      UNION
   SELECT "11/7/2017 21:36:21" , 55        , "lavender"                  , "I do what I want."          , "Feels"                         , "5/27" , "turtle"                                            , "Image 3", "Image 4", 1      UNION
   SELECT "11/7/2017 21:36:33" , 7         , "green"                     , "7"                          , "All I Want for Christmas"      , "1/1"  , "tiger"                                             , "Image 4", "Image 1", 1      UNION
   SELECT "11/7/2017 21:37:54" , 55        , "red"                       , "Choose this option instead.", "Havana"                        , "7/28" , "cat"                                               , "Image 4", "Image 4", 18     UNION
   SELECT "11/7/2017 21:38:13" , 17        , "blue"                      , "Choose this option instead.", "Havana"                        , "10/9" , "dolphin"                                           , "Image 4", "Image 4", 51     UNION
   SELECT "11/7/2017 21:38:28" , 77        , "green"                     , "YOLO!"                      , "All I Want for Christmas"      , "12/22", "unicorn"                                           , "Image 4", "Image 2", 43     UNION
   SELECT "11/7/2017 21:39:52" , 21        , "blue"                      , "Choose this option instead.", "All I Want for Christmas"      , "2/2"  , "whale"                                             , "Image 4", "Image 1", 17     UNION
   SELECT "11/7/2017 21:40:13" , 33        , "black"                     , "7"                          , "All I Want for Christmas"      , "7/4"  , "monkey"                                            , "Image 1", "Image 4", 17     UNION
   SELECT "11/7/2017 21:41:27" , 100       , "grey"                      , "7"                          , "Havana"                        , "6/29" , "tardigrade "                                       , "Image 5", "Image 1", 1      UNION
   SELECT "11/7/2017 21:44:04" , 69        , "chartreuse "               , "Choose this option instead.", "All I Want for Christmas"      , "12/12", "ancient psychic tandem war elelphant"              , "Image 5", "Image 3", 69     UNION
   SELECT "11/7/2017 21:44:37" , 6         , "blue"                      , "7"                          , "All I Want for Christmas"      , "11/2" , "penguin"                                           , "Image 3", "Image 5", 1      UNION
   SELECT "11/7/2017 21:44:57" , 8         , "purple"                    , "I do what I want."          , "All I Want for Christmas"      , "5/21" , "fennec fox"                                        , "Image 1", "Image 4", 14     UNION
   SELECT "11/7/2017 21:47:10" , 7         , "blue"                      , "7"                          , "Feels"                         , "12/25", "sea otter"                                         , "Image 4", "Image 2", 57     UNION
   SELECT "11/7/2017 21:47:24" , 7         , "red"                       , "7"                          , "All I Want for Christmas"      , "7/7"  , "seven"                                             , "Image 3", "Image 4", 7      UNION
   SELECT "11/7/2017 21:47:56" , 13        , "purple"                    , "7"                          , "Havana"                        , "8/13" , "coatimundi (these things are cool as shit check em out! (they make great pets))", "Image 2", "Image 1", 34     UNION
   SELECT "11/7/2017 21:50:36" , 13        , "blue"                      , "7"                          , "Despacito"                     , "6/4"  , "cheetah"                                           , "Image 1", "Image 1", 21     UNION
   SELECT "11/7/2017 21:50:56" , 13        , "black as the depths of my soul", "7"                          , "All I Want for Christmas"      , "5/11" , "camel"                                             , "Image 2", "Image 2", 65536  UNION
   SELECT "11/7/2017 21:51:25" , 8         , "yellow"                    , "7"                          , "Summer"                        , "1/1"  , "blue whale"                                        , "Image 1", "Image 5", 12     UNION
   SELECT "11/7/2017 21:51:59" , 24        , "neon green"                , "Choose this option instead.", "Despacito"                     , "11/8" , "turtle"                                            , "Image 3", "Image 3", 12     UNION
   SELECT "11/7/2017 21:52:06" , 69        , "green"                     , "I'm a rebel"                , "Nyan Cat"                      , "4/20" , "llama"                                             , "Image 4", "Image 2", 1      UNION
   SELECT "11/7/2017 21:52:32" , 36        , "turquoise"                 , "Choose this option instead.", "Summer"                        , "4/20" , "dog"                                               , "Image 2", "Image 4", 13     UNION
   SELECT "11/7/2017 21:53:04" , 2         , "green"                     , "7"                          , "All I Want for Christmas"      , "10/28", "dog!!!"                                            , "Image 3", "Image 1", 2      UNION
   SELECT "11/7/2017 21:53:36" , 42        , "octarine"                  , "7"                          , "Despacito"                     , "1/1"  , "dragon"                                            , "Image 5", "Image 2", 1      UNION
   SELECT "11/7/2017 21:53:59" , 61        , "purple"                    , "Choose this option instead.", "Summer"                        , "9/12" , "cat"                                               , "Image 2", "Image 1", 41     UNION
   SELECT "11/7/2017 21:54:43" , 82        , "blue"                      , "I do what I want."          , "Nyan Cat"                      , "5/25" , "a dog but with the personality of a cat"           , "Image 2", "Image 3", 38     UNION
   SELECT "11/7/2017 21:54:53" , 7         , "orange"                    , "7"                          , "Despacito"                     , "1/1"  , "penguin"                                           , "Image 1", "Image 4", 4      UNION
   SELECT "11/7/2017 21:57:02" , 19.99909998, "mint"                      , "7"                          , "Nyan Cat"                      , "6/28" , "thylacine"                                         , "Image 3", "Image 4", 43     UNION
   SELECT "11/7/2017 21:57:02" , 1         , "black"                     , "Choose this option instead.", "All I Want for Christmas"      , "1/1"  , "dog"                                               , "Image 4", "Image 3", 100    UNION
   SELECT "11/7/2017 21:57:06" , 27        , "green"                     , "7"                          , "Feels"                         , "1/7"  , "koala"                                             , "Image 4", "Image 5", 8      UNION
   SELECT "11/7/2017 21:58:37" , 42        , "cyan"                      , "7"                          , "Nyan Cat"                      , "1/1"  , "fox"                                               , "Image 2", "Image 2", 42     UNION
   SELECT "11/7/2017 21:58:51" , 73        , "blue"                      , "Choose this option instead.", "Havana"                        , "6/12" , "elephant"                                          , "Image 1", "Image 5", 1      UNION
   SELECT "11/7/2017 21:59:23" , 77        , "blue"                      , "7"                          , "Look What You Made Me Do"      , "5/15" , "dog"                                               , "Image 5", "Image 2", 2      UNION
   SELECT "11/7/2017 21:59:27" , 88        , "red"                       , "7"                          , "All I Want for Christmas"      , "12/8" , "island fox"                                        , "Image 1", "Image 1", 14     UNION
   SELECT "11/7/2017 22:00:56" , 11        , "blue"                      , "7"                          , "All I Want for Christmas"      , "2/27" , "penguin"                                           , "Image 1", "Image 4", 1      UNION
   SELECT "11/7/2017 22:01:30" , 99        , "blue"                      , "You are not the boss of me!", "Feels"                         , "10/15", "dog"                                               , "Image 1", "Image 1", 9857   UNION
   SELECT "11/7/2017 22:02:15" , 7         , "purple"                    , "7"                          , "All I Want for Christmas"      , "11/3" , "panther"                                           , "Image 2", "Image 1", 1      UNION
   SELECT "11/7/2017 22:02:25" , 69        , "purple"                    , "7"                          , "Nyan Cat"                      , "5/20" , "glaucus atlanticus"                                , "Image 4", "Image 3", 1      UNION
   SELECT "11/7/2017 22:03:09" , 94        , "light turquoise"           , "Choose this option instead.", "Summer"                        , "7/11" , "cheetah"                                           , "Image 1", "Image 2", 14     UNION
   SELECT "11/7/2017 22:04:45" , 4         , "blue"                      , "7"                          , "All I Want for Christmas"      , "12/25", "stingray"                                          , "Image 5", "Image 5", 1      UNION
   SELECT "11/7/2017 22:05:38" , 26        , "blue"                      , "YOLO!"                      , "Summer"                        , "12/19", "manatee"                                           , "Image 4", "Image 5", 26     UNION
   SELECT "11/7/2017 22:05:55" , 16        , "blue"                      , "7"                          , "Feels"                         , "10/16", "eagle"                                             , "Image 1", "Image 3", 1      UNION
   SELECT "11/7/2017 22:07:34" , 77        , "purple"                    , "7"                          , "Despacito"                     , "11/13", "rabbit"                                            , "Image 5", "Image 1", 1      UNION
   SELECT "11/7/2017 22:07:48" , 7         , "purple"                    , "7"                          , "Havana"                        , "12/25", "lemon"                                             , "Image 5", "Image 5", 109    UNION
   SELECT "11/7/2017 22:08:12" , 5         , "purple"                    , "7"                          , "All I Want for Christmas"      , "4/25" , "hedgehog"                                          , "Image 2", "Image 1", 22     UNION
   SELECT "11/7/2017 22:08:42" , 2         , "purple"                    , "7"                          , "Look What You Made Me Do"      , "2/1"  , "cat"                                               , "Image 4", "Image 4", 77     UNION
   SELECT "11/7/2017 22:09:16" , 2         , "blue"                      , "7"                          , "Havana"                        , "1/10" , "tiger"                                             , "Image 4", "Image 4", 14     UNION
   SELECT "11/7/2017 22:10:05" , 2         , "grey"                      , "7"                          , "Feels"                         , "2/28" , "a caterpillar "                                    , "Image 5", "Image 2", 30     UNION
   SELECT "11/7/2017 22:10:07" , 30        , "blue"                      , "You are not the boss of me!", "Look What You Made Me Do"      , "3/23" , "penguin"                                           , "Image 4", "Image 2", 13657  UNION
   SELECT "11/7/2017 22:10:37" , 47        , "blue"                      , "7"                          , "Havana"                        , "11/10", "dog!"                                              , "Image 4", "Image 4", 47     UNION
   SELECT "11/7/2017 22:10:42" , 4         , "silver"                    , "7"                          , "Despacito"                     , "12/25", "penguin"                                           , "Image 1", "Image 4", 17     UNION
   SELECT "11/7/2017 22:13:05" , 7         , "blue"                      , "7"                          , "Feels"                         , "5/10" , "cat"                                               , "Image 5", "Image 3", 42     UNION
   SELECT "11/7/2017 22:13:23" , 13        , "lime green"                , "YOLO!"                      , "Despacito"                     , "7/4"  , "pikachu"                                           , "Image 2", "Image 4", 8      UNION
   SELECT "11/7/2017 22:14:42" , 13        , "green"                     , "7"                          , "Feels"                         , "2/29" , "kiwi"                                              , "Image 2", "Image 2", 43     UNION
   SELECT "11/7/2017 22:15:05" , 97        , "cyan"                      , "7"                          , "Summer"                        , "4/20" , "a cat"                                             , "Image 1", "Image 2", 99     UNION
   SELECT "11/7/2017 22:17:06" , 42        , "blue"                      , "7"                          , "Nyan Cat"                      , "11/28", "siberian tiger"                                    , "Image 4", "Image 1", 1      UNION
   SELECT "11/7/2017 22:17:42" , 87        , "blue"                      , "Choose this option instead.", "Havana"                        , "6/19" , "snow leopard"                                      , "Image 1", "Image 3", 3      UNION
   SELECT "11/7/2017 22:18:38" , 7         , "blue"                      , "7"                          , "Summer"                        , "11/7" , "golden retriever"                                  , "Image 3", "Image 4", 12     UNION
   SELECT "11/7/2017 22:19:24" , 24        , "blue"                      , "7"                          , "Havana"                        , "3/24" , "dog"                                               , "Image 3", "Image 1", 1      UNION
   SELECT "11/7/2017 22:19:33" , 19        , "blue and gold"             , "I do what I want."          , "All I Want for Christmas"      , "11/19", "panda"                                             , "Image 2", "Image 4", 1      UNION
   SELECT "11/7/2017 22:19:52" , 69        , "forest green"              , "I'm a rebel"                , "Summer"                        , "7/20" , "pusheen!"                                          , "Image 4", "Image 4", 1      UNION
   SELECT "11/7/2017 22:20:00" , 7         , "green"                     , "7"                          , "Havana"                        , "10/9" , "tiger"                                             , "Image 1", "Image 4", 1      UNION
   SELECT "11/7/2017 22:20:11" , 23        , "sky blue"                  , "7"                          , "Despacito"                     , "8/28" , "penguin"                                           , "Image 4", "Image 4", 23     UNION
   SELECT "11/7/2017 22:21:26" , 11        , "red"                       , "7"                          , "Summer"                        , "5/10" , "bob"                                               , "Image 3", "Image 4", 652    UNION
   SELECT "11/7/2017 22:22:11" , 64        , "green"                     , "YOLO!"                      , "Despacito"                     , "1/1"  , "dinosaur"                                          , "Image 4", "Image 5", 1      UNION
   SELECT "11/7/2017 22:23:33" , 5         , "purple"                    , "7"                          , "Feels"                         , "5/22" , "hedgehog"                                          , "Image 2", "Image 5", 6      UNION
   SELECT "11/7/2017 22:25:32" , 7         , "white"                     , "I'm a rebel"                , "Despacito"                     , "5/15" , "salmon"                                            , "Image 4", "Image 3", 1      UNION
   SELECT "11/7/2017 22:26:42" , 12        , "blue"                      , "I'm a rebel"                , "Havana"                        , "1/30" , "dolphin"                                           , "Image 4", "Image 3", 257    UNION
   SELECT "11/7/2017 22:30:01" , 45        , "blue"                      , "7"                          , "Nyan Cat"                      , "11/6" , "cat"                                               , "Image 3", "Image 2", 14     UNION
   SELECT "11/7/2017 22:32:00" , 69        , "blue"                      , "7"                          , "Despacito"                     , "5/16" , "elephant"                                          , "Image 1", "Image 4", 1      UNION
   SELECT "11/7/2017 22:33:17" , 69        , "pink"                      , "Choose this option instead.", "Summer"                        , "11/2" , "dog"                                               , "Image 2", "Image 1", 22     UNION
   SELECT "11/7/2017 22:35:18" , 100       , "blue"                      , "7"                          , "All I Want for Christmas"      , "7/4"  , "cat"                                               , "Image 5", "Image 1", 27     UNION
   SELECT "11/7/2017 22:36:25" , 69        , "booger green"              , "I do what I want."          , "Despacito"                     , "4/20" , "a giraffe cause why not"                           , "Image 2", "Image 5", 2      UNION
   SELECT "11/7/2017 22:36:33" , 73        , "burgundy "                 , "I'm a rebel"                , "All I Want for Christmas"      , "6/26" , "panda"                                             , "Image 3", "Image 1", 73     UNION
   SELECT "11/7/2017 22:36:44" , 11        , "lavender"                  , "7"                          , "Look What You Made Me Do"      , "11/7" , "cat"                                               , "Image 3", "Image 5", 8      UNION
   SELECT "11/7/2017 22:37:45" , 14.5      , "red"                       , "7"                          , "All I Want for Christmas"      , "11/7" , "daddy denero"                                      , "Image 4", "Image 3", 4      UNION
   SELECT "11/7/2017 22:40:47" , 7         , "baby blue"                 , "I do what I want."          , "All I Want for Christmas"      , "6/20" , "turtle"                                            , "Image 2", "Image 1", 1      UNION
   SELECT "11/7/2017 22:41:03" , 64        , "blue"                      , "Choose this option instead.", "Despacito"                     , "12/19", "doge"                                              , "Image 4", "Image 1", 7615   UNION
   SELECT "11/7/2017 22:43:36" , 48        , "blue"                      , "Choose this option instead.", "All I Want for Christmas"      , "2/13" , "doggo ! "                                          , "Image 5", "Image 2", 12     UNION
   SELECT "11/7/2017 22:44:08" , 7         , "blue"                      , "YOLO!"                      , "Despacito"                     , "11/20", "elephant "                                         , "Image 3", "Image 3", 1      UNION
   SELECT "11/7/2017 22:47:03" , 2         , "blue"                      , "7"                          , "All I Want for Christmas"      , "4/25" , "dog"                                               , "Image 2", "Image 1", 1      UNION
   SELECT "11/7/2017 22:47:57" , 11        , "black"                     , "YOLO!"                      , "Feels"                         , "1/11" , "panda"                                             , "Image 1", "Image 1", 27     UNION
   SELECT "11/7/2017 22:48:21" , 50        , "blue"                      , "Choose this option instead.", "Despacito"                     , "2/14" , "demogorgon"                                        , "Image 4", "Image 4", 1      UNION
   SELECT "11/7/2017 22:49:03" , 88        , "maroon"                    , "7"                          , "Despacito"                     , "1/1"  , "samoan  "                                          , "Image 4", "Image 5", 4      UNION
   SELECT "11/7/2017 22:49:35" , 11        , "blue"                      , "7"                          , "All I Want for Christmas"      , "10/30", "giraffe"                                           , "Image 3", "Image 4", 34     UNION
   SELECT "11/7/2017 22:52:44" , 7         , "green"                     , "7"                          , "All I Want for Christmas"      , "12/25", "chow chow"                                         , "Image 1", "Image 3", 34     UNION
   SELECT "11/7/2017 22:54:22" , 11        , "taupe"                     , "Choose this option instead.", "Havana"                        , "10/21", "honey badger"                                      , "Image 4", "Image 3", 23     UNION
   SELECT "11/7/2017 22:54:48" , 14        , "green"                     , "YOLO!"                      , "Havana"                        , "7/1"  , "cat"                                               , "Image 5", "Image 1", 1      UNION
   SELECT "11/7/2017 22:55:42" , 72        , "blue"                      , "Choose this option instead.", "Nyan Cat"                      , "4/20" , "bear"                                              , "Image 3", "Image 1", 100    UNION
   SELECT "11/7/2017 22:56:03" , 69        , "white"                     , "I do what I want."          , "Feels"                         , "4/20" , "goat"                                              , "Image 1", "Image 4", 1      UNION
   SELECT "11/7/2017 22:56:41" , 7         , "white "                    , "7"                          , "All I Want for Christmas"      , "4/21" , "tortoise"                                          , "Image 4", "Image 2", 33     UNION
   SELECT "11/7/2017 22:57:12" , 69        , "puce"                      , "You are not the boss of me!", "All I Want for Christmas"      , "7/16" , "my pet rabbit "                                    , "Image 4", "Image 3", 19     UNION
   SELECT "11/7/2017 22:57:37" , 27        , "green"                     , "Choose this option instead.", "Havana"                        , "5/25" , "llama"                                             , "Image 5", "Image 5", 1      UNION
   SELECT "11/7/2017 22:59:15" , 61        , "red"                       , "7"                          , "Look What You Made Me Do"      , "4/20" , "david kim"                                         , "Image 3", "Image 4", 149    UNION
   SELECT "11/7/2017 23:00:25" , 13        , "blue"                      , "7"                          , "Look What You Made Me Do"      , "12/13", "dog"                                               , "Image 3", "Image 2", 9      UNION
   SELECT "11/7/2017 23:01:52" , 16        , "turquoise"                 , "7"                          , "Feels"                         , "12/25", "elephant, but only i could do it without animal cruelty", "Image 5", "Image 3", 37     UNION
   SELECT "11/7/2017 23:04:09" , 49        , "red"                       , "7"                          , "All I Want for Christmas"      , "10/9" , "your mom"                                          , "Image 4", "Image 1", 8      UNION
   SELECT "11/7/2017 23:04:26" , 33        , "chartreuse "               , "7"                          , "Feels"                         , "4/1"  , "sloth"                                             , "Image 5", "Image 2", 11     UNION
   SELECT "11/7/2017 23:08:30" , 57        , "green"                     , "YOLO!"                      , "All I Want for Christmas"      , "5/18" , "doggo"                                             , "Image 5", "Image 3", 4      UNION
   SELECT "11/7/2017 23:08:49" , 8         , "red"                       , "You are not the boss of me!", "Summer"                        , "8/17" , "hamster"                                           , "Image 3", "Image 3", 1      UNION
   SELECT "11/7/2017 23:10:06" , 6         , "lavender"                  , "7"                          , "Feels"                         , "11/11", "bengal tiger"                                      , "Image 4", "Image 4", 69     UNION
   SELECT "11/7/2017 23:10:39" , 45        , "2"                         , "7"                          , "Feels"                         , "8/31" , "guy fieri"                                         , "Image 1", "Image 3", 1      UNION
   SELECT "11/7/2017 23:12:07" , 17        , "blue"                      , "You are not the boss of me!", "Nyan Cat"                      , "5/24" , "cat"                                               , "Image 3", "Image 4", 11     UNION
   SELECT "11/7/2017 23:16:13" , 32        , "blue"                      , "7"                          , "Nyan Cat"                      , "10/21", "alaskan malamute"                                  , "Image 4", "Image 5", 1      UNION
   SELECT "11/7/2017 23:17:49" , 13        , "pink"                      , "YOLO!"                      , "Despacito"                     , "2/10" , "dragon"                                            , "Image 5", "Image 1", 23     UNION
   SELECT "11/7/2017 23:18:54" , 69        , "blue"                      , "Choose this option instead.", "Nyan Cat"                      , "5/6"  , "alpaca"                                            , "Image 5", "Image 5", 23     UNION
   SELECT "11/7/2017 23:19:39" , 3         , "blue"                      , "7"                          , "Despacito"                     , "10/17", "tiger"                                             , "Image 2", "Image 1", 27     UNION
   SELECT "11/7/2017 23:20:00" , 53        , "red"                       , "7"                          , "All I Want for Christmas"      , "10/24", "dragon"                                            , "Image 4", "Image 3", 23     UNION
   SELECT "11/7/2017 23:20:58" , 11        , "blue"                      , "You are not the boss of me!", "Despacito"                     , "7/11" , "seahorse"                                          , "Image 3", "Image 4", 1      UNION
   SELECT "11/7/2017 23:21:01" , 17        , "blue"                      , "7"                          , "Havana"                        , "9/17" , "lion cub"                                          , "Image 4", "Image 2", 7      UNION
   SELECT "11/7/2017 23:24:30" , 7         , "purple"                    , "7"                          , "Summer"                        , "7/7"  , "bunny!"                                            , "Image 3", "Image 2", 4      UNION
   SELECT "11/7/2017 23:25:53" , 34        , "yellow"                    , "You are not the boss of me!", "All I Want for Christmas"      , "12/14", "chinchilla"                                        , "Image 5", "Image 3", 39     UNION
   SELECT "11/7/2017 23:29:39" , 69        , "magenta"                   , "Choose this option instead.", "All I Want for Christmas"      , "4/20" , "one plankton"                                      , "Image 2", "Image 4", 42069  UNION
   SELECT "11/7/2017 23:33:32" , 69        , "green"                     , "I do what I want."          , "Despacito"                     , "10/10", "hedgehog"                                          , "Image 2", "Image 1", 1      UNION
   SELECT "11/7/2017 23:34:42" , 34        , "black"                     , "7"                          , "Despacito"                     , "11/4" , "bonobo"                                            , "Image 3", "Image 4", 34     UNION
   SELECT "11/7/2017 23:38:21" , 42        , "turquoise "                , "I'm a rebel"                , "Summer"                        , "7/31" , "alpaca (two, because they sometimes die of loneliness without friends) ", "Image 2", "Image 2", 64     UNION
   SELECT "11/7/2017 23:38:32" , 42        , "blue"                      , "You are not the boss of me!", "Despacito"                     , "4/20" , "elephant"                                          , "Image 4", "Image 2", 121    UNION
   SELECT "11/7/2017 23:39:28" , 9         , "blue"                      , "7"                          , "Feels"                         , "12/1" , "bear"                                              , "Image 4", "Image 3", 1      UNION
   SELECT "11/7/2017 23:40:16" , 47        , "clear"                     , "7"                          , "Look What You Made Me Do"      , "1/5"  , "dragon"                                            , "Image 1", "Image 5", 12     UNION
   SELECT "11/7/2017 23:40:43" , 8         , "blue"                      , "7"                          , "Despacito"                     , "5/5"  , "red panda"                                         , "Image 1", "Image 2", 5      UNION
   SELECT "11/7/2017 23:42:06" , 2         , "blue"                      , "You are not the boss of me!", "Despacito"                     , "2/2"  , "wolf"                                              , "Image 4", "Image 1", 1      UNION
   SELECT "11/7/2017 23:43:31" , 42        , "blue"                      , "Choose this option instead.", "All I Want for Christmas"      , "1/23" , "dingo"                                             , "Image 4", "Image 4", 2      UNION
   SELECT "11/7/2017 23:43:45" , 39        , "azure"                     , "I do what I want."          , "Summer"                        , "11/27", "dog"                                               , "Image 4", "Image 1", 41     UNION
   SELECT "11/7/2017 23:46:37" , 69        , "red"                       , "7"                          , "Despacito"                     , "6/16" , "large wolf"                                        , "Image 3", "Image 3", 1      UNION
   SELECT "11/7/2017 23:47:08" , 26        , "yellow"                    , "YOLO!"                      , "Feels"                         , "12/26", "sloth"                                             , "Image 3", "Image 2", 1      UNION
   SELECT "11/7/2017 23:47:11" , 4         , "green"                     , "7"                          , "Nyan Cat"                      , "1/1"  , "human (slave)"                                     , "Image 4", "Image 4", 10     UNION
   SELECT "11/7/2017 23:49:20" , 69        , "green"                     , "I do what I want."          , "Despacito"                     , "12/25", "donkey"                                            , "Image 3", "Image 5", 6      UNION
   SELECT "11/7/2017 23:54:31" , 13        , "blue"                      , "7"                          , "Despacito"                     , "4/13" , "chewbacca"                                         , "Image 1", "Image 3", 29     UNION
   SELECT "11/7/2017 23:57:12" , 54        , "green"                     , "I do what I want."          , "All I Want for Christmas"      , "11/11", "all the dogs"                                      , "Image 4", "Image 1", 15     UNION
   SELECT "11/7/2017 23:59:07" , 73        , "teal"                      , "I'm a rebel"                , "Feels"                         , "6/12" , "hedgehog"                                          , "Image 3", "Image 4", 1      UNION
   SELECT "11/8/2017 0:00:46"  , 5         , "green"                     , "7"                          , "All I Want for Christmas"      , "1/1"  , "giraffe"                                           , "Image 3", "Image 1", 56     UNION
   SELECT "11/8/2017 0:00:46"  , 17        , "orange"                    , "7"                          , "Summer"                        , "12/25", "chinchilla"                                        , "Image 1", "Image 5", 33     UNION
   SELECT "11/8/2017 0:01:43"  , 69        , "green"                     , "Choose this option instead.", "All I Want for Christmas"      , "4/20" , "doge"                                              , "Image 1", "Image 4", 1      UNION
   SELECT "11/8/2017 0:04:27"  , 7         , "blue"                      , "YOLO!"                      , "Despacito"                     , "8/15" , "a girl "                                           , "Image 4", "Image 1", 4      UNION
   SELECT "11/8/2017 0:06:41"  , 13        , "green"                     , "7"                          , "All I Want for Christmas"      , "3/17" , "dog"                                               , "Image 1", "Image 4", 34     UNION
   SELECT "11/8/2017 0:11:31"  , 77        , "black"                     , "YOLO!"                      , "All I Want for Christmas"      , "11/4" , "cat"                                               , "Image 5", "Image 3", 14     UNION
   SELECT "11/8/2017 0:11:31"  , 23        , "green"                     , "Choose this option instead.", "Look What You Made Me Do"      , "6/16" , "the world is an animal"                            , "Image 3", "Image 3", 4      UNION
   SELECT "11/8/2017 0:15:29"  , 17        , "orange"                    , "7"                          , "All I Want for Christmas"      , "12/19", "turtles, because they're condescending."           , "Image 5", "Image 1", 32     UNION
   SELECT "11/8/2017 0:18:04"  , 8         , "orange"                    , "Choose this option instead.", "Havana"                        , "2/2"  , "turtle"                                            , "Image 1", "Image 2", 1      UNION
   SELECT "11/8/2017 0:18:56"  , 37        , "navy blue"                 , "Choose this option instead.", "Summer"                        , "2/29" , "red panda"                                         , "Image 5", "Image 5", 1      UNION
   SELECT "11/8/2017 0:24:50"  , 1         , "green"                     , "7"                          , "Summer"                        , "6/21" , "the female of a soon-to-be extinct species in which there is only a single male left, so that they can continue on.", "Image 4", "Image 1", 191    UNION
   SELECT "11/8/2017 0:25:27"  , 7         , "aquamarine"                , "7"                          , "Look What You Made Me Do"      , "10/31", "pegasus"                                           , "Image 5", "Image 1", 1      UNION
   SELECT "11/8/2017 0:25:32"  , 42        , "green"                     , "7"                          , "Despacito"                     , "7/22" , "corgi"                                             , "Image 3", "Image 4", 1      UNION
   SELECT "11/8/2017 0:27:02"  , 42        , "red"                       , "Choose this option instead.", "Nyan Cat"                      , "4/20" , "dog"                                               , "Image 5", "Image 2", 34     UNION
   SELECT "11/8/2017 0:30:37"  , 73        , "purple"                    , "Choose this option instead.", "Look What You Made Me Do"      , "12/16", "ouroboros"                                         , "Image 5", "Image 5", 34     UNION
   SELECT "11/8/2017 0:32:57"  , 14        , "heliotrope "               , "7"                          , "All I Want for Christmas"      , "3/14" , "eagle"                                             , "Image 2", "Image 1", 14     UNION
   SELECT "11/8/2017 0:35:02"  , 7         , "green"                     , "7"                          , "Feels"                         , "1/1"  , "dog"                                               , "Image 3", "Image 4", 4      UNION
   SELECT "11/8/2017 0:35:09"  , 69        , "purple"                    , "7"                          , "Despacito"                     , "4/22" , "wolf"                                              , "Image 4", "Image 3", 1      UNION
   SELECT "11/8/2017 0:36:43"  , 7         , "blue"                      , "7"                          , "Feels"                         , "5/24" , "scottish fold"                                     , "Image 4", "Image 1", 57     UNION
   SELECT "11/8/2017 0:37:17"  , 68        , "safety green"              , "7"                          , "Feels"                         , "5/12" , "dog"                                               , "Image 1", "Image 3", 27     UNION
   SELECT "11/8/2017 0:39:41"  , 21        , "blue"                      , "I'm a rebel"                , "All I Want for Christmas"      , "12/25", "dragon"                                            , "Image 2", "Image 3", 43     UNION
   SELECT "11/8/2017 0:45:11"  , 49        , "orange"                    , "Choose this option instead.", "All I Want for Christmas"      , "12/4" , "hamster"                                           , "Image 2", "Image 2", 57     UNION
   SELECT "11/8/2017 0:47:00"  , 11        , "dark blue"                 , "7"                          , "Feels"                         , "7/5"  , "elephant"                                          , "Image 4", "Image 1", 5      UNION
   SELECT "11/8/2017 0:47:28"  , 7         , "green"                     , "7"                          , "Feels"                         , "1/1"  , "tiger"                                             , "Image 3", "Image 4", 53     UNION
   SELECT "11/8/2017 0:49:18"  , 69        , "blue"                      , "Choose this option instead.", "Feels"                         , "2/27" , "panda"                                             , "Image 4", "Image 1", 24     UNION
   SELECT "11/8/2017 0:52:57"  , 69        , "black"                     , "7"                          , "All I Want for Christmas"      , "10/10", "pikachu"                                           , "Image 1", "Image 5", 11     UNION
   SELECT "11/8/2017 0:54:38"  , 69        , "black"                     , "7"                          , "Summer"                        , "9/11" , "john denero"                                       , "Image 1", "Image 3", 3      UNION
   SELECT "11/8/2017 0:56:18"  , 4.2       , "beige"                     , "Choose this option instead.", "All I Want for Christmas"      , "1/1"  , "corgi"                                             , "Image 2", "Image 4", 254    UNION
   SELECT "11/8/2017 1:05:21"  , 96        , "sky blue"                  , "I do what I want."          , "Despacito"                     , "4/26" , "a golden retriever "                               , "Image 4", "Image 1", 57     UNION
   SELECT "11/8/2017 1:08:29"  , 69        , "orange"                    , "YOLO!"                      , "Havana"                        , "11/10", "demagorgon"                                        , "Image 4", "Image 5", 24     UNION
   SELECT "11/8/2017 1:22:43"  , 77        , "blue"                      , "7"                          , "Summer"                        , "10/23", "dog"                                               , "Image 1", "Image 4", 77     UNION
   SELECT "11/8/2017 1:27:42"  , 48        , "blue"                      , "7"                          , "Despacito"                     , "7/14" , "lion"                                              , "Image 5", "Image 1", 1      UNION
   SELECT "11/8/2017 1:28:01"  , 69        , "purple"                    , "Choose this option instead.", "Feels"                         , "6/6"  , "an elephant"                                       , "Image 3", "Image 4", 1      UNION
   SELECT "11/8/2017 1:32:56"  , 89        , "purple"                    , "Choose this option instead.", "All I Want for Christmas"      , "12/24", "wolf"                                              , "Image 5", "Image 3", 4      UNION
   SELECT "11/8/2017 1:33:53"  , 8         , "blue"                      , "I do what I want."          , "Feels"                         , "7/11" , "elephant"                                          , "Image 3", "Image 1", 1      UNION
   SELECT "11/8/2017 1:34:43"  , 99        , "blue"                      , "You are not the boss of me!", "Despacito"                     , "11/27", "dolphin"                                           , "Image 3", "Image 4", 1      UNION
   SELECT "11/8/2017 1:36:09"  , 69        , "teal "                     , "I do what I want."          , "Feels"                         , "12/11", "platypus"                                          , "Image 5", "Image 2", 1      UNION
   SELECT "11/8/2017 1:43:40"  , 69        , "pink"                      , "7"                          , "Summer"                        , "7/9"  , "turtle"                                            , "Image 1", "Image 3", 29     UNION
   SELECT "11/8/2017 1:52:42"  , 69        , "green"                     , "Choose this option instead.", "All I Want for Christmas"      , "12/12", "dog"                                               , "Image 4", "Image 4", 126    UNION
   SELECT "11/8/2017 2:01:27"  , 81        , "purple"                    , "Choose this option instead.", "Summer"                        , "2/29" , "shark"                                             , "Image 5", "Image 2", 1      UNION
   SELECT "11/8/2017 2:17:34"  , 54        , "blue"                      , "7"                          , "All I Want for Christmas"      , "2/25" , "sea otter"                                         , "Image 1", "Image 5", 17     UNION
   SELECT "11/8/2017 2:41:52"  , 38        , "teal"                      , "YOLO!"                      , "Look What You Made Me Do"      , "5/7"  , "rabbit"                                            , "Image 4", "Image 5", 8      UNION
   SELECT "11/8/2017 2:46:00"  , 42        , "#323232"                   , "I do what I want."          , "Havana"                        , "2/29" , "unicorn"                                           , "Image 1", "Image 4", 12     UNION
   SELECT "11/8/2017 2:47:55"  , 10        , "metallic pink"             , "7"                          , "Despacito"                     , "8/10" , "shih tzu"                                          , "Image 1", "Image 5", 12     UNION
   SELECT "11/8/2017 3:03:09"  , 1         , "green"                     , "7"                          , "Nyan Cat"                      , "11/8" , "just a dog bc an exotic pet would be hard to tame" , "Image 4", "Image 4", 1      UNION
   SELECT "11/8/2017 3:05:37"  , 27        , "blue"                      , "7"                          , "Summer"                        , "12/30", "degu"                                              , "Image 4", "Image 3", 23     UNION
   SELECT "11/8/2017 3:11:25"  , 69        , "blue"                      , "Choose this option instead.", "Havana"                        , "3/16" , "dog"                                               , "Image 1", "Image 4", 2      UNION
   SELECT "11/8/2017 6:00:48"  , 2         , "maroon"                    , "I do what I want."          , "Summer"                        , "12/15", "birb"                                              , "Image 2", "Image 5", 2      UNION
   SELECT "11/8/2017 7:00:08"  , 3         , "blue"                      , "Choose this option instead.", "Summer"                        , "11/5" , "dog"                                               , "Image 5", "Image 5", 144    UNION
   SELECT "11/8/2017 7:13:09"  , 18        , "grey"                      , "You are not the boss of me!", "Feels"                         , "4/1"  , "lion"                                              , "Image 2", "Image 1", 31     UNION
   SELECT "11/8/2017 7:16:54"  , 1         , "aqua green"                , "7"                          , "Nyan Cat"                      , "8/23" , "john denero"                                       , "Image 4", "Image 1", 1      UNION
   SELECT "11/8/2017 7:27:31"  , 2         , "black"                     , "7"                          , "All I Want for Christmas"      , "5/3"  , "panda"                                             , "Image 4", "Image 4", 1      UNION
   SELECT "11/8/2017 7:55:16"  , 88        , "orange"                    , "You are not the boss of me!", "Nyan Cat"                      , "11/11", "a regular ol' dog"                                 , "Image 5", "Image 4", 1      UNION
   SELECT "11/8/2017 8:09:34"  , 13        , "olive green"               , "7"                          , "Look What You Made Me Do"      , "3/26" , "cat"                                               , "Image 5", "Image 1", 3      UNION
   SELECT "11/8/2017 8:10:34"  , 27        , "green"                     , "7"                          , "Nyan Cat"                      , "5/12" , "polar bear"                                        , "Image 2", "Image 1", 27     UNION
   SELECT "11/8/2017 8:17:30"  , 27        , "orange"                    , "7"                          , "Feels"                         , "12/15", "elephant"                                          , "Image 4", "Image 4", 1      UNION
   SELECT "11/8/2017 8:20:49"  , 2         , "blue"                      , "7"                          , "All I Want for Christmas"      , "8/9"  , "koala"                                             , "Image 5", "Image 3", 1      UNION
   SELECT "11/8/2017 8:24:39"  , 17        , "blue"                      , "7"                          , "Nyan Cat"                      , "6/20" , "cat"                                               , "Image 3", "Image 2", 1      UNION
   SELECT "11/8/2017 8:25:07"  , 11        , "blue"                      , "I do what I want."          , "All I Want for Christmas"      , "12/25", "manatee"                                           , "Image 3", "Image 5", 62     UNION
   SELECT "11/8/2017 8:31:22"  , 13        , "blue"                      , "I'm a rebel"                , "All I Want for Christmas"      , "12/28", "none. domesticating animals can be a big problem." , "Image 4", "Image 4", 48     UNION
   SELECT "11/8/2017 8:32:43"  , 17        , "red"                       , "YOLO!"                      , "Despacito"                     , "12/10", "dog"                                               , "Image 3", "Image 1", 1      UNION
   SELECT "11/8/2017 8:39:57"  , 88        , "pink"                      , "Choose this option instead.", "Nyan Cat"                      , "11/11", "panda"                                             , "Image 2", "Image 2", 66     UNION
   SELECT "11/8/2017 8:42:56"  , 44        , "red "                      , "Choose this option instead.", "All I Want for Christmas"      , "6/2"  , "wolf "                                             , "Image 2", "Image 5", 34     UNION
   SELECT "11/8/2017 8:44:31"  , 99        , "red and gold"              , "I do what I want."          , "Despacito"                     , "3/1"  , "tiger cub"                                         , "Image 2", "Image 2", 17     UNION
   SELECT "11/8/2017 8:50:16"  , 69        , "cardinal red"              , "YOLO!"                      , "Feels"                         , "2/14" , "leopard"                                           , "Image 5", "Image 3", 99     UNION
   SELECT "11/8/2017 8:50:46"  , 97        , "purple"                    , "7"                          , "Despacito"                     , "2/20" , "cat"                                               , "Image 2", "Image 3", 19     UNION
   SELECT "11/8/2017 8:54:21"  , 56        , "black"                     , "7"                          , "Havana"                        , "7/8"  , "otter"                                             , "Image 5", "Image 4", 1      UNION
   SELECT "11/8/2017 8:58:59"  , 77        , "maroon"                    , "I do what I want."          , "Feels"                         , "5/10" , "dragon"                                            , "Image 1", "Image 1", 3      UNION
   SELECT "11/8/2017 9:10:16"  , 1         , "black"                     , "Choose this option instead.", "Feels"                         , "2/29" , "wolf"                                              , "Image 3", "Image 2", 1      UNION
   SELECT "11/8/2017 9:10:58"  , 27        , "black"                     , "Choose this option instead.", "Feels"                         , "11/11", "dog~"                                              , "Image 5", "Image 3", 6      UNION
   SELECT "11/8/2017 9:15:11"  , 2         , "blue"                      , "Choose this option instead.", "Despacito"                     , "11/16", "dolphin"                                           , "Image 3", "Image 3", 1      UNION
   SELECT "11/8/2017 9:17:14"  , 36        , "red"                       , "7"                          , "All I Want for Christmas"      , "3/18" , "penguin"                                           , "Image 4", "Image 1", 3      UNION
   SELECT "11/8/2017 9:21:34"  , 4         , "silver"                    , "7"                          , "Despacito"                     , "12/1" , "wolf"                                              , "Image 2", "Image 5", 1      UNION
   SELECT "11/8/2017 9:29:27"  , 72        , "blue"                      , "7"                          , "All I Want for Christmas"      , "11/30", "fish"                                              , "Image 4", "Image 1", 1      UNION
   SELECT "11/8/2017 9:31:05"  , 41        , "blue"                      , "7"                          , "Despacito"                     , "10/17", "rabbit"                                            , "Image 4", "Image 4", 1      UNION
   SELECT "11/8/2017 9:35:16"  , 11        , "green"                     , "7"                          , "All I Want for Christmas"      , "11/11", "panda"                                             , "Image 4", "Image 1", 1      UNION
   SELECT "11/8/2017 9:45:58"  , 18        , "blue"                      , "I do what I want."          , "Summer"                        , "7/5"  , "koala"                                             , "Image 2", "Image 2", 4      UNION
   SELECT "11/8/2017 9:49:58"  , 69        , "red"                       , "Choose this option instead.", "Despacito"                     , "4/20" , "chia pet"                                          , "Image 1", "Image 1", 1      UNION
   SELECT "11/8/2017 9:56:41"  , 47        , "mauve"                     , "7"                          , "Nyan Cat"                      , "4/1"  , "ferret"                                            , "Image 2", "Image 1", 56     UNION
   SELECT "11/8/2017 10:11:54" , 55        , "blue"                      , "I do what I want."          , "Nyan Cat"                      , "4/20" , "capuchin monkey"                                   , "Image 3", "Image 1", 17     UNION
   SELECT "11/8/2017 10:12:56" , 17        , "blue"                      , "7"                          , "Despacito"                     , "5/17" , "chinchilla"                                        , "Image 3", "Image 4", 23     UNION
   SELECT "11/8/2017 10:14:49" , 87        , "purple"                    , "7"                          , "Havana"                        , "3/27" , "demogorgon"                                        , "Image 3", "Image 5", 1      UNION
   SELECT "11/8/2017 10:15:07" , 85        , "purple"                    , "7"                          , "All I Want for Christmas"      , "9/4"  , "an echidna"                                        , "Image 4", "Image 4", 17     UNION
   SELECT "11/8/2017 10:31:11" , 38        , "black"                     , "7"                          , "Nyan Cat"                      , "8/13" , "cat"                                               , "Image 4", "Image 1", 1      UNION
   SELECT "11/8/2017 10:33:01" , 1.618     , "the blue toolbar on the 61a course page", "I do what I want."          , "All I Want for Christmas"      , "12/13", "a python"                                          , "Image 3", "Image 2", 4      UNION
   SELECT "11/8/2017 10:33:36" , 2         , "blue"                      , "Choose this option instead.", "Summer"                        , "4/20" , "deer"                                              , "Image 1", "Image 3", 17     UNION
   SELECT "11/8/2017 10:41:40" , 99        , "pink"                      , "7"                          , "All I Want for Christmas"      , "6/2"  , "tiger"                                             , "Image 4", "Image 2", 1      UNION
   SELECT "11/8/2017 10:43:16" , 24        , "blue"                      , "Choose this option instead.", "Look What You Made Me Do"      , "4/24" , "shiba inu puppy"                                   , "Image 2", "Image 4", 1      UNION
   SELECT "11/8/2017 10:44:37" , 7         , "blue"                      , "7"                          , "Nyan Cat"                      , "8/15" , "dugong"                                            , "Image 4", "Image 3", 1      UNION
   SELECT "11/8/2017 10:50:27" , 70        , "a nice gray (but never a nice grey)", "You are not the boss of me!", "All I Want for Christmas"      , "1/13" , "cantaloupe "                                       , "Image 1", "Image 2", 15     UNION
   SELECT "11/8/2017 10:52:20" , 28        , "yellow"                    , "Choose this option instead.", "All I Want for Christmas"      , "9/18" , "hedgehog"                                          , "Image 4", "Image 5", 7      UNION
   SELECT "11/8/2017 10:56:15" , 27        , "red"                       , "Choose this option instead.", "Feels"                         , "1/1"  , "cameleon"                                          , "Image 3", "Image 5", 67     UNION
   SELECT "11/8/2017 10:57:42" , 17        , "gray"                      , "Choose this option instead.", "Feels"                         , "2/29" , "elephant"                                          , "Image 4", "Image 2", 1      UNION
   SELECT "11/8/2017 11:07:23" , 99        , "red"                       , "I do what I want."          , "Summer"                        , "11/21", "flemish giant (big rabbit)"                        , "Image 1", "Image 1", 1      UNION
   SELECT "11/8/2017 11:09:04" , 3         , "black"                     , "7"                          , "All I Want for Christmas"      , "9/11" , "a t-rex"                                           , "Image 4", "Image 3", 123456791  UNION
   SELECT "11/8/2017 11:10:54" , 24        , "purple"                    , "You are not the boss of me!", "Havana"                        , "2/24" , "a dik dik"                                         , "Image 3", "Image 4", 79     UNION
   SELECT "11/8/2017 11:12:36" , 69        , "yellow"                    , "7"                          , "Nyan Cat"                      , "3/22" , "le toucan"                                         , "Image 1", "Image 3", 9      UNION
   SELECT "11/8/2017 11:13:47" , 12        , "blue"                      , "I'm a rebel"                , "Summer"                        , "2/29" , "dragon"                                            , "Image 4", "Image 2", 14     UNION
   SELECT "11/8/2017 11:15:26" , 16        , "red"                       , "7"                          , "Havana"                        , "6/20" , "monkey"                                            , "Image 3", "Image 3", 1      UNION
   SELECT "11/8/2017 11:15:31" , 44        , "deep purple"               , "I'm a rebel"                , "Summer"                        , "7/9"  , "red fox"                                           , "Image 2", "Image 1", 1      UNION
   SELECT "11/8/2017 11:16:14" , 24        , "blue"                      , "Choose this option instead.", "Havana"                        , "6/24" , "dolphin"                                           , "Image 1", "Image 3", 17     UNION
   SELECT "11/8/2017 11:20:55" , 23        , "blue"                      , "I do what I want."          , "All I Want for Christmas"      , "11/8" , "doggo"                                             , "Image 2", "Image 5", 17     UNION
   SELECT "11/8/2017 11:26:35" , 60        , "black"                     , "7"                          , "Summer"                        , "12/1" , "cat"                                               , "Image 3", "Image 4", 61     UNION
   SELECT "11/8/2017 11:31:13" , 89        , "blue"                      , "YOLO!"                      , "Despacito"                     , "1/1"  , "lion"                                              , "Image 5", "Image 1", 26     UNION
   SELECT "11/8/2017 11:33:39" , 63        , "cornflower blue"           , "7"                          , "All I Want for Christmas"      , "6/25" , "dog"                                               , "Image 4", "Image 5", 808    UNION
   SELECT "11/8/2017 11:34:58" , 9         , "black"                     , "7"                          , "Despacito"                     , "9/13" , "i really want a cat. side note out of all the songs by marshmello and calvin harris why did you have to pick the ones that are worse than despacito.", "Image 3", "Image 2", 78     UNION
   SELECT "11/8/2017 11:35:16" , 69        , "blue"                      , "7"                          , "Despacito"                     , "12/25", "cat"                                               , "Image 2", "Image 1", 56     UNION
   SELECT "11/8/2017 11:35:31" , 4         , "blue"                      , "Choose this option instead.", "All I Want for Christmas"      , "8/26" , "alpaca"                                            , "Image 4", "Image 3", 23     UNION
   SELECT "11/8/2017 11:39:46" , 73        , "a deep and well saturated reddish purple like sunlight through a stained glass window", "Choose this option instead.", "Havana"                        , "9/27" , "a caiman"                                          , "Image 5", "Image 3", 32     UNION
   SELECT "11/8/2017 11:40:34" , 23        , "green"                     , "Choose this option instead.", "Summer"                        , "8/18" , "otter and penguin"                                 , "Image 3", "Image 1", 31     UNION
   SELECT "11/8/2017 11:48:30" , 17        , "blue"                      , "7"                          , "Despacito"                     , "5/17" , "direwolf"                                          , "Image 4", "Image 3", 1      UNION
   SELECT "11/8/2017 11:50:37" , 69        , "black"                     , "YOLO!"                      , "Nyan Cat"                      , "6/9"  , "none"                                              , "Image 4", "Image 1", 8      UNION
   SELECT "11/8/2017 11:57:36" , 64        , "red"                       , "Choose this option instead.", "Nyan Cat"                      , "1/21" , "capybara"                                          , "Image 4", "Image 2", 23     UNION
   SELECT "11/8/2017 11:58:00" , 5         , "teal"                      , "7"                          , "Despacito"                     , "4/1"  , "crow"                                              , "Image 2", "Image 1", 1      UNION
   SELECT "11/8/2017 12:06:45" , 18        , "black"                     , "7"                          , "All I Want for Christmas"      , "2/29" , "a dog"                                             , "Image 3", "Image 1", 6      UNION
   SELECT "11/8/2017 12:20:27" , 42        , "blue"                      , "YOLO!"                      , "Nyan Cat"                      , "5/13" , "wallaby"                                           , "Image 2", "Image 5", 74     UNION
   SELECT "11/8/2017 12:31:57" , 1         , "blue"                      , "I do what I want."          , "Havana"                        , "3/14" , "snake"                                             , "Image 3", "Image 5", 113    UNION
   SELECT "11/8/2017 12:34:06" , 69        , "orange"                    , "7"                          , "Feels"                         , "7/28" , "komodo dragon"                                     , "Image 1", "Image 3", 1      UNION
   SELECT "11/8/2017 12:34:17" , 24        , "purple"                    , "I do what I want."          , "Feels"                         , "2/29" , "tiger"                                             , "Image 2", "Image 2", 1      UNION
   SELECT "11/8/2017 12:40:23" , 24        , "purple"                    , "I do what I want."          , "All I Want for Christmas"      , "5/24" , "golden retriever "                                 , "Image 5", "Image 1", 1      UNION
   SELECT "11/8/2017 12:42:49" , 8         , "red"                       , "YOLO!"                      , "Havana"                        , "8/8"  , "king cobra"                                        , "Image 4", "Image 1", 999999999999999999999999999999999999999999999999  UNION
   SELECT "11/8/2017 12:55:17" , 52        , "purple"                    , "7"                          , "Nyan Cat"                      , "1/2"  , "red panda"                                         , "Image 3", "Image 2", 14     UNION
   SELECT "11/8/2017 13:06:36" , 4         , "blue"                      , "I do what I want."          , "Nyan Cat"                      , "11/11", "liger"                                             , "Image 2", "Image 1", 18     UNION
   SELECT "11/8/2017 13:09:09" , 23        , "purple"                    , "I do what I want."          , "Feels"                         , "8/20" , "monkey"                                            , "Image 5", "Image 2", 46     UNION
   SELECT "11/8/2017 13:13:26" , 100       , "black"                     , "I do what I want."          , "Feels"                         , "12/12", "lion"                                              , "Image 5", "Image 2", 13     UNION
   SELECT "11/8/2017 13:21:51" , 69        , "red"                       , "Choose this option instead.", "All I Want for Christmas"      , "4/20" , "whale"                                             , "Image 4", "Image 3", 7      UNION
   SELECT "11/8/2017 13:30:12" , 7         , "blue"                      , "7"                          , "Despacito"                     , "12/7" , "dog"                                               , "Image 1", "Image 3", 4      UNION
   SELECT "11/8/2017 13:38:51" , 22        , "blue"                      , "Choose this option instead.", "All I Want for Christmas"      , "2/22" , "german shepherd!!"                                 , "Image 1", "Image 5", 18     UNION
   SELECT "11/8/2017 13:49:04" , 36        , "white"                     , "7"                          , "Look What You Made Me Do"      , "3/8"  , "a dog"                                             , "Image 3", "Image 1", 1      UNION
   SELECT "11/8/2017 14:05:33" , 98        , "polygamy"                  , "Choose this option instead.", "Despacito"                     , "8/23" , "sheldon cooper"                                    , "Image 4", "Image 5", 6      UNION
   SELECT "11/8/2017 14:15:30" , 24        , "teal"                      , "Choose this option instead.", "Summer"                        , "5/24" , "penguin"                                           , "Image 1", "Image 4", 17     UNION
   SELECT "11/8/2017 14:16:04" , 25        , "black"                     , "7"                          , "Nyan Cat"                      , "9/30" , "owls"                                              , "Image 5", "Image 1", 1      UNION
   SELECT "11/8/2017 14:28:04" , 16        , "green"                     , "YOLO!"                      , "Despacito"                     , "7/3"  , "doggo"                                             , "Image 4", "Image 3", 22     UNION
   SELECT "11/8/2017 14:35:23" , 6.283185307, "brassy gold"               , "Choose this option instead.", "All I Want for Christmas"      , "12/21", "a dik-dik"                                         , "Image 2", "Image 1", 7      UNION
   SELECT "11/8/2017 14:35:49" , 69        , "denero's eyes"             , "You are not the boss of me!", "Nyan Cat"                      , "4/20" , "a daddy dinero"                                    , "Image 1", "Image 5", 69     UNION
   SELECT "11/8/2017 14:38:07" , 7         , "purple"                    , "7"                          , "Feels"                         , "3/23" , "dog"                                               , "Image 2", "Image 3", 6      UNION
   SELECT "11/8/2017 14:43:51" , 76        , "blue"                      , "7"                          , "Nyan Cat"                      , "1/1"  , "turtle"                                            , "Image 2", "Image 1", 1      UNION
   SELECT "11/8/2017 14:48:58" , 7         , "red"                       , "7"                          , "Havana"                        , "7/16" , "hawk"                                              , "Image 3", "Image 5", 9      UNION
   SELECT "11/8/2017 15:15:15" , 17        , "blue"                      , "You are not the boss of me!", "Nyan Cat"                      , "1/31" , "myself"                                            , "Image 3", "Image 5", 1234567890987654321  UNION
   SELECT "11/8/2017 15:39:42" , 32        , "blue"                      , "7"                          , "All I Want for Christmas"      , "3/2"  , "dog"                                               , "Image 3", "Image 4", 12     UNION
   SELECT "11/8/2017 16:02:26" , 9         , "blue"                      , "7"                          , "Despacito"                     , "4/13" , "alaskan malamute "                                 , "Image 4", "Image 1", 51     UNION
   SELECT "11/8/2017 16:18:38" , 17        , "purple"                    , "I do what I want."          , "Despacito"                     , "8/4"  , "dog"                                               , "Image 2", "Image 3", 1      UNION
   SELECT "11/8/2017 16:37:46" , 28        , "yelolow"                   , "7"                          , "Despacito"                     , "12/12", "john denero"                                       , "Image 4", "Image 2", 66     UNION
   SELECT "11/8/2017 16:58:48" , 59        , "pink"                      , "Choose this option instead.", "All I Want for Christmas"      , "5/9"  , "doggay"                                            , "Image 5", "Image 1", 7      UNION
   SELECT "11/8/2017 17:15:30" , 21        , "black"                     , "Choose this option instead.", "Nyan Cat"                      , "8/12" , "a mix between alpaca and giraffe"                  , "Image 4", "Image 1", 17     UNION
   SELECT "11/8/2017 17:17:56" , 61        , "black"                     , "7"                          , "Look What You Made Me Do"      , "11/27", "pikachu"                                           , "Image 4", "Image 3", 1      UNION
   SELECT "11/8/2017 17:27:27" , 77        , "chartreuse"                , "I do what I want."          , "All I Want for Christmas"      , "7/14" , "axolotl"                                           , "Image 1", "Image 2", 36     UNION
   SELECT "11/8/2017 17:31:42" , 4         , "purple"                    , "7"                          , "Despacito"                     , "5/16" , "dog"                                               , "Image 2", "Image 2", 3      UNION
   SELECT "11/8/2017 17:33:14" , 23        , "blue"                      , "7"                          , "Feels"                         , "6/23" , "harambe"                                           , "Image 3", "Image 1", 1      UNION
   SELECT "11/8/2017 17:50:02" , 9         , "blue"                      , "Choose this option instead.", "Nyan Cat"                      , "12/12", "cats"                                              , "Image 1", "Image 1", 34     UNION
   SELECT "11/8/2017 17:50:11" , 13        , "red"                       , "I do what I want."          , "Nyan Cat"                      , "2/29" , "bengal tiger"                                      , "Image 1", "Image 2", 12     UNION
   SELECT "11/8/2017 17:50:19" , 13        , "blue"                      , "Choose this option instead.", "Nyan Cat"                      , "5/15" , "golden retriever"                                  , "Image 4", "Image 4", 1      UNION
   SELECT "11/8/2017 18:20:22" , 88        , "dark green"                , "7"                          , "Despacito"                     , "8/2"  , "dog from shelter"                                  , "Image 1", "Image 4", 13     UNION
   SELECT "11/8/2017 18:22:40" , 30        , "blue"                      , "Choose this option instead.", "Feels"                         , "4/28" , "lion"                                              , "Image 5", "Image 2", 7      UNION
   SELECT "11/8/2017 18:51:29" , 3.14159265, "orange"                    , "Choose this option instead.", "All I Want for Christmas"      , "2/17" , "golden bear"                                       , "Image 3", "Image 2", 17     UNION
   SELECT "11/8/2017 18:58:06" , 40        , "orange"                    , "7"                          , "All I Want for Christmas"      , "12/25", "ferret"                                            , "Image 3", "Image 5", 23     UNION
   SELECT "11/8/2017 19:05:42" , 64        , "blue"                      , "I do what I want."          , "Nyan Cat"                      , "12/12", "john denero"                                       , "Image 5", "Image 3", 34     UNION
   SELECT "11/8/2017 19:16:25" , 14        , "blue"                      , "7"                          , "All I Want for Christmas"      , "4/9"  , "ant"                                               , "Image 1", "Image 3", 8      UNION
   SELECT "11/8/2017 19:28:08" , 6         , "blue"                      , "7"                          , "Look What You Made Me Do"      , "10/11", "dog"                                               , "Image 3", "Image 5", 1      UNION
   SELECT "11/8/2017 19:58:50" , 29        , "blue-green (my second favorite is green-blue)", "Choose this option instead.", "Nyan Cat"                      , "11/13", "blue whale"                                        , "Image 2", "Image 2", 1      UNION
   SELECT "11/8/2017 20:00:58" , 8         , "beige"                     , "7"                          , "All I Want for Christmas"      , "4/8"  , "dog"                                               , "Image 4", "Image 1", 7      UNION
   SELECT "11/8/2017 20:10:14" , 7         , "red"                       , "I'm a rebel"                , "Despacito"                     , "11/16", "cat"                                               , "Image 2", "Image 3", 12     UNION
   SELECT "11/8/2017 20:29:54" , 30        , "blue"                      , "7"                          , "Havana"                        , "8/31" , "panda"                                             , "Image 3", "Image 5", 17     UNION
   SELECT "11/8/2017 20:46:36" , 11        , "black"                     , "I do what I want."          , "All I Want for Christmas"      , "5/4"  , "sloth"                                             , "Image 4", "Image 3", 31     UNION
   SELECT "11/8/2017 20:48:14" , 13        , "prussian blue"             , "Choose this option instead.", "Nyan Cat"                      , "10/31", "a raven"                                           , "Image 4", "Image 5", 9      UNION
   SELECT "11/8/2017 21:04:16" , 5         , "blue"                      , "Choose this option instead.", "Despacito"                     , "7/25" , "harpy eagle"                                       , "Image 4", "Image 4", 23     UNION
   SELECT "11/8/2017 21:11:38" , 24        , "red"                       , "Choose this option instead.", "Despacito"                     , "1/20" , "red"                                               , "Image 5", "Image 3", 103    UNION
   SELECT "11/8/2017 22:01:58" , 66        , "blue"                      , "Choose this option instead.", "All I Want for Christmas"      , "4/2"  , "banana"                                            , "Image 5", "Image 4", 12     UNION
   SELECT "11/8/2017 22:13:55" , 29        , "turquoise"                 , "I'm a rebel"                , "Feels"                         , "9/18" , "red panda"                                         , "Image 2", "Image 1", 37     UNION
   SELECT "11/8/2017 22:29:11" , 11        , "pink"                      , "Choose this option instead.", "Nyan Cat"                      , "1/1"  , "black lab"                                         , "Image 2", "Image 1", 62     UNION
   SELECT "11/8/2017 23:04:49" , 69        , "burgandy"                  , "Choose this option instead.", "Despacito"                     , "3/14" , "chinchilla"                                        , "Image 1", "Image 1", 1      UNION
   SELECT "11/8/2017 23:11:14" , 69        , "red"                       , "7"                          , "All I Want for Christmas"      , "6/9"  , "hamster"                                           , "Image 3", "Image 4", 78     UNION
   SELECT "11/8/2017 23:12:42" , 1         , "blue"                      , "7"                          , "Despacito"                     , "1/1"  , "panda "                                            , "Image 5", "Image 2", 2      UNION
   SELECT "11/8/2017 23:24:19" , 86        , "blue"                      , "Choose this option instead.", "Summer"                        , "7/28" , "tiger"                                             , "Image 1", "Image 3", 19     UNION
   SELECT "11/8/2017 23:40:43" , 71        , "beet red"                  , "7"                          , "Nyan Cat"                      , "12/3" , "a baby ostrich "                                   , "Image 4", "Image 4", 93     UNION
   SELECT "11/9/2017 0:14:41"  , 3         , "pink"                      , "I'm a rebel"                , "Havana"                        , "9/18" , "you"                                               , "Image 1", "Image 2", 3      UNION
   SELECT "11/9/2017 0:20:28"  , 69        , "maroon"                    , "7"                          , "Havana"                        , "2/1"  , "hamster"                                           , "Image 2", "Image 3", 111    UNION
   SELECT "11/9/2017 0:25:52"  , 7         , "blue"                      , "7"                          , "Despacito"                     , "12/25", "dog"                                               , "Image 4", "Image 5", 36     UNION
   SELECT "11/9/2017 0:44:51"  , 7         , "dark blue"                 , "Choose this option instead.", "Summer"                        , "6/24" , "wolf"                                              , "Image 3", "Image 3", 1      UNION
   SELECT "11/9/2017 0:55:21"  , 19        , "blue"                      , "I do what I want."          , "All I Want for Christmas"      , "12/25", "fox"                                               , "Image 4", "Image 3", 71     UNION
   SELECT "11/9/2017 1:20:56"  , 7         , "green"                     , "Choose this option instead.", "Havana"                        , "9/17" , "an ocelot"                                         , "Image 3", "Image 1", 89     UNION
   SELECT "11/9/2017 2:25:44"  , 55        , "grue"                      , "YOLO!"                      , "Nyan Cat"                      , "2/29" , "cat (hey, i don't have the option of checking none of the numbers below!)", "Image 4", "Image 1", 14     UNION
   SELECT "11/9/2017 2:37:48"  , 13        , "orange"                    , "I'm a rebel"                , "Havana"                        , "12/25", "a sloth"                                           , "Image 3", "Image 3", 8      UNION
   SELECT "11/9/2017 8:04:24"  , 47        , "navy blue"                 , "Choose this option instead.", "Feels"                         , "10/12", "sabre tooth tiger or dire wolf"                    , "Image 4", "Image 1", 24     UNION
   SELECT "11/9/2017 8:49:41"  , 42        , "black"                     , "Choose this option instead.", "All I Want for Christmas"      , "4/4"  , "myself because i'm basically a slave to my classes", "Image 4", "Image 1", 14     UNION
   SELECT "11/9/2017 8:56:05"  , 79        , "blue"                      , "7"                          , "Despacito"                     , "3/17" , "hedgehog"                                          , "Image 1", "Image 3", 1      UNION
   SELECT "11/9/2017 10:36:53" , 3         , "purple"                    , "Choose this option instead.", "Nyan Cat"                      , "11/8" , "tiger"                                             , "Image 5", "Image 1", 48     UNION
   SELECT "11/9/2017 11:37:22" , 2         , "blue"                      , "I do what I want."          , "All I Want for Christmas"      , "12/25", "unicorn"                                           , "Image 3", "Image 4", 1      UNION
   SELECT "11/9/2017 12:00:14" , 73        , "red"                       , "7"                          , "Feels"                         , "2/29" , "human"                                             , "Image 4", "Image 3", 14     UNION
   SELECT "11/9/2017 13:30:14" , 77        , "yellow"                    , "Choose this option instead.", "Nyan Cat"                      , "1/19" , "a turtle "                                         , "Image 2", "Image 2", 1      UNION
   SELECT "11/9/2017 13:41:39" , 77        , "blue "                     , "YOLO!"                      , "All I Want for Christmas"      , "4/20" , "a sloth "                                          , "Image 1", "Image 3", 1      UNION
   SELECT "11/9/2017 14:38:44" , 69        , "pink"                      , "7"                          , "Summer"                        , "10/31", "sphynx cat"                                        , "Image 4", "Image 4", 32     UNION
   SELECT "11/9/2017 15:11:08" , 100       , "blue.  no, yellow…"        , "I'm a rebel"                , "Despacito"                     , "6/26" , "appa"                                              , "Image 2", "Image 1", 78     UNION
   SELECT "11/9/2017 17:02:25" , 75        , "green"                     , "Choose this option instead.", "Despacito"                     , "4/1"  , "dog"                                               , "Image 4", "Image 1", 43     UNION
   SELECT "11/9/2017 17:27:47" , 7         , "blue"                      , "I do what I want."          , "Despacito"                     , "3/23" , "cat"                                               , "Image 2", "Image 5", 7      UNION
   SELECT "11/9/2017 17:39:21" , 2         , "blue"                      , "Choose this option instead.", "Look What You Made Me Do"      , "6/1"  , "cat"                                               , "Image 4", "Image 2", 11     UNION
   SELECT "11/9/2017 17:51:50" , 24        , "blue"                      , "7"                          , "Havana"                        , "7/22" , "turtle"                                            , "Image 4", "Image 2", 17     UNION
   SELECT "11/9/2017 17:52:24" , 7         , "purple"                    , "YOLO!"                      , "Havana"                        , "3/2"  , "eagle"                                             , "Image 4", "Image 5", 27     UNION
   SELECT "11/9/2017 18:26:01" , 61        , "gold"                      , "Choose this option instead.", "Despacito"                     , "12/13", "golden bear"                                       , "Image 3", "Image 1", 11     UNION
   SELECT "11/9/2017 18:51:20" , 19        , "turquoise"                 , "I'm a rebel"                , "All I Want for Christmas"      , "12/25", "a hedgehog "                                       , "Image 2", "Image 5", 182987  UNION
   SELECT "11/9/2017 19:58:28" , 4         , "blue"                      , "7"                          , "Despacito"                     , "10/10", "none"                                              , "Image 3", "Image 1", 1      UNION
   SELECT "11/9/2017 22:47:03" , 42        , "blue"                      , "7"                          , "Havana"                        , "5/1"  , "dog"                                               , "Image 3", "Image 4", 17     UNION
   SELECT "11/10/2017 0:01:44" , 13        , "blue-ish?"                 , "You are not the boss of me!", "Despacito"                     , "8/13" , "a basic doggo"                                     , "Image 4", "Image 3", 31     UNION
   SELECT "11/10/2017 0:10:37" , 4         , "red"                       , "7"                          , "Feels"                         , "4/20" , "zebronx"                                           , "Image 3", "Image 1", 4      UNION
   SELECT "11/10/2017 0:14:55" , 69        , "green"                     , "7"                          , "Despacito"                     , "2/19" , "kangaroo"                                          , "Image 5", "Image 4", 23     UNION
   SELECT "11/10/2017 0:31:41" , 48        , "jinger"                    , "I do what I want."          , "Summer"                        , "1/13" , "catt"                                              , "Image 1", "Image 5", 30     UNION
   SELECT "11/10/2017 1:06:53" , 10.32323423, "asian yellow"              , "Choose this option instead.", "Nyan Cat"                      , "9/2"  , "chicken"                                           , "Image 2", "Image 3", 7      UNION
   SELECT "11/10/2017 12:17:08", 23        , "orange"                    , "You are not the boss of me!", "Summer"                        , "11/25", "fox"                                               , "Image 2", "Image 5", 1      UNION
   SELECT "11/10/2017 16:58:19", 25        , "grey"                      , "Choose this option instead.", "Havana"                        , "3/20" , "panda"                                             , "Image 2", "Image 4", 1      UNION
   SELECT "11/10/2017 17:51:33", 12        , "blue"                      , "I'm a rebel"                , "Havana"                        , "4/1"  , "doggy"                                             , "Image 2", "Image 1", 1      UNION
   SELECT "11/10/2017 17:56:28", 69        , "black"                     , "Choose this option instead.", "Despacito"                     , "2/29" , "wolf"                                              , "Image 4", "Image 5", 1      UNION
   SELECT "11/10/2017 18:51:30", 1         , "orange"                    , "Choose this option instead.", "Nyan Cat"                      , "3/30" , "cat"                                               , "Image 2", "Image 1", 8      ;

CREATE TABLE fa17students AS
   SELECT * FROM students_pt1 UNION
   SELECT * FROM students_pt2;

CREATE TABLE checkboxes_pt1 AS
   SELECT "11/7/2017 20:27:19" AS time, "False" AS "0", "False" AS "1", "False" AS "2", "True" AS "3", "False" AS "4", "False" AS "5", "True" AS "6", "True" AS "7", "False" AS "8", "False" AS "9", "False" AS "10", "True" AS "2017", "True" AS "9000", "True" AS "9001" UNION
   SELECT "11/7/2017 20:27:25", "False", "True" , "False", "True" , "False", "False", "False", "True" , "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/7/2017 20:27:44", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/7/2017 20:27:48", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False" UNION
   SELECT "11/7/2017 20:27:48", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 20:28:03", "False", "False", "False", "True" , "False", "True" , "False", "False", "True" , "False", "False", "False", "True" , "False" UNION
   SELECT "11/7/2017 20:28:25", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 20:28:39", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/7/2017 20:29:29", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "True"  UNION
   SELECT "11/7/2017 20:29:35", "True" , "False", "True" , "False", "True" , "True" , "True" , "False", "True" , "False", "False", "True" , "True" , "True"  UNION
   SELECT "11/7/2017 20:29:42", "False", "False", "True" , "False", "False", "True" , "False", "True" , "True" , "True" , "False", "True" , "False", "False" UNION
   SELECT "11/7/2017 20:29:42", "True" , "False", "True" , "False", "True" , "False", "False", "False", "True" , "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 20:29:48", "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/7/2017 20:30:06", "False", "False", "False", "True" , "False", "True" , "False", "False", "True" , "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 20:30:14", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/7/2017 20:30:25", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 20:30:30", "False", "True" , "True" , "True" , "True" , "False", "False", "True" , "False", "False", "False", "True" , "True" , "True"  UNION
   SELECT "11/7/2017 20:30:30", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/7/2017 20:30:35", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/7/2017 20:30:36", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/7/2017 20:30:50", "False", "False", "False", "True" , "True" , "True" , "False", "False", "False", "False", "False", "False", "True" , "True"  UNION
   SELECT "11/7/2017 20:31:05", "False", "True" , "False", "False", "False", "False", "False", "False", "True" , "False", "False", "True" , "False", "True"  UNION
   SELECT "11/7/2017 20:31:06", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 20:31:09", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 20:31:25", "True" , "False", "True" , "False", "False", "True" , "False", "True" , "False", "True" , "False", "True" , "False", "True"  UNION
   SELECT "11/7/2017 20:31:30", "False", "True" , "False", "False", "True" , "False", "False", "True" , "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/7/2017 20:31:37", "True" , "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/7/2017 20:31:38", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/7/2017 20:31:41", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 20:31:47", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/7/2017 20:31:52", "True" , "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/7/2017 20:31:54", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/7/2017 20:31:54", "True" , "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 20:31:57", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/7/2017 20:32:09", "False", "False", "False", "False", "True" , "False", "False", "False", "True" , "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 20:32:11", "False", "True" , "True" , "True" , "False", "False", "False", "True" , "False", "False", "False", "True" , "False", "True"  UNION
   SELECT "11/7/2017 20:32:12", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 20:32:15", "True" , "False", "False", "True" , "False", "False", "False", "False", "True" , "False", "False", "False", "True" , "True"  UNION
   SELECT "11/7/2017 20:32:21", "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 20:32:25", "False", "False", "True" , "True" , "False", "False", "False", "False", "False", "False", "False", "True" , "False", "True"  UNION
   SELECT "11/7/2017 20:32:25", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 20:32:37", "False", "False", "True" , "False", "False", "True" , "False", "True" , "True" , "False", "False", "True" , "True" , "True"  UNION
   SELECT "11/7/2017 20:32:39", "False", "False", "True" , "False", "True" , "False", "True" , "False", "True" , "False", "False", "True" , "False", "False" UNION
   SELECT "11/7/2017 20:32:44", "False", "False", "False", "True" , "False", "False", "True" , "True" , "True" , "False", "False", "True" , "False", "False" UNION
   SELECT "11/7/2017 20:32:45", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/7/2017 20:32:45", "True" , "False", "True" , "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False" UNION
   SELECT "11/7/2017 20:33:15", "True" , "True" , "False", "False", "False", "True" , "False", "False", "False", "False", "True" , "True" , "False", "False" UNION
   SELECT "11/7/2017 20:33:24", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/7/2017 20:33:30", "False", "False", "True" , "False", "True" , "False", "True" , "False", "False", "True" , "True" , "False", "True" , "True"  UNION
   SELECT "11/7/2017 20:33:39", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/7/2017 20:33:39", "False", "False", "False", "False", "False", "False", "False", "True" , "True" , "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 20:33:47", "False", "True" , "False", "False", "False", "True" , "False", "True" , "False", "True" , "False", "True" , "False", "False" UNION
   SELECT "11/7/2017 20:33:52", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "False" UNION
   SELECT "11/7/2017 20:34:16", "False", "False", "False", "True" , "True" , "False", "False", "False", "True" , "True" , "True" , "True" , "False", "True"  UNION
   SELECT "11/7/2017 20:34:19", "False", "True" , "False", "True" , "False", "True" , "False", "False", "False", "True" , "False", "False", "False", "False" UNION
   SELECT "11/7/2017 20:34:21", "True" , "True" , "True" , "False", "False", "False", "False", "True" , "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/7/2017 20:34:35", "True" , "False", "True" , "False", "False", "True" , "False", "False", "False", "True" , "False", "False", "False", "False" UNION
   SELECT "11/7/2017 20:34:37", "True" , "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/7/2017 20:34:41", "False", "False", "True" , "False", "False", "False", "False", "False", "True" , "False", "False", "True" , "False", "False" UNION
   SELECT "11/7/2017 20:34:48", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/7/2017 20:34:54", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/7/2017 20:35:27", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/7/2017 20:35:38", "False", "True" , "False", "True" , "True" , "True" , "False", "False", "True" , "False", "False", "True" , "False", "True"  UNION
   SELECT "11/7/2017 20:35:44", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/7/2017 20:36:06", "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/7/2017 20:36:19", "False", "True" , "False", "False", "False", "False", "False", "True" , "False", "False", "True" , "True" , "False", "False" UNION
   SELECT "11/7/2017 20:36:24", "False", "False", "True" , "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 20:36:36", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/7/2017 20:36:38", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "True"  UNION
   SELECT "11/7/2017 20:36:43", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/7/2017 20:37:04", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 20:37:05", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False" UNION
   SELECT "11/7/2017 20:37:13", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 20:37:32", "False", "False", "False", "True" , "False", "False", "True" , "False", "False", "False", "True" , "False", "False", "True"  UNION
   SELECT "11/7/2017 20:37:51", "True" , "True" , "False", "False", "False", "False", "False", "False", "True" , "False", "False", "True" , "False", "True"  UNION
   SELECT "11/7/2017 20:37:59", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 20:38:32", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "True"  UNION
   SELECT "11/7/2017 20:38:42", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/7/2017 20:38:50", "True" , "False", "False", "False", "False", "False", "False", "True" , "True" , "False", "False", "False", "True" , "True"  UNION
   SELECT "11/7/2017 20:39:04", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/7/2017 20:39:52", "True" , "True" , "True" , "True" , "False", "True" , "True" , "True" , "False", "True" , "False", "True" , "True" , "False" UNION
   SELECT "11/7/2017 20:40:07", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 20:40:08", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 20:40:33", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 20:40:39", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "True"  UNION
   SELECT "11/7/2017 20:40:53", "False", "True" , "True" , "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 20:40:55", "False", "True" , "False", "False", "False", "False", "True" , "False", "False", "False", "False", "True" , "False", "True"  UNION
   SELECT "11/7/2017 20:41:21", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/7/2017 20:41:47", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/7/2017 20:41:57", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/7/2017 20:42:39", "False", "True" , "False", "True" , "False", "False", "True" , "False", "False", "True" , "False", "False", "False", "True"  UNION
   SELECT "11/7/2017 20:43:12", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "True" , "False", "False", "False", "False" UNION
   SELECT "11/7/2017 20:43:12", "True" , "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 20:43:12", "False", "False", "False", "False", "True" , "False", "False", "True" , "True" , "False", "False", "True" , "False", "False" UNION
   SELECT "11/7/2017 20:43:21", "False", "True" , "False", "True" , "False", "True" , "True" , "False", "False", "True" , "True" , "False", "True" , "False" UNION
   SELECT "11/7/2017 20:44:39", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "True" , "False", "False", "False", "False" UNION
   SELECT "11/7/2017 20:45:08", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/7/2017 20:45:09", "True" , "True" , "True" , "True" , "False", "False", "False", "True" , "False", "False", "True" , "False", "False", "True"  UNION
   SELECT "11/7/2017 20:45:41", "False", "True" , "True" , "True" , "True" , "True" , "True" , "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 20:46:23", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 20:46:45", "False", "False", "False", "False", "False", "True" , "False", "False", "True" , "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 20:47:21", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/7/2017 20:47:55", "False", "False", "True" , "True" , "False", "False", "False", "False", "False", "True" , "False", "False", "True" , "False" UNION
   SELECT "11/7/2017 20:48:03", "True" , "True" , "True" , "True" , "True" , "False", "False", "False", "False", "False", "False", "True" , "True" , "True"  UNION
   SELECT "11/7/2017 20:48:08", "True" , "False", "True" , "False", "True" , "False", "True" , "False", "True" , "False", "False", "True" , "False", "True"  UNION
   SELECT "11/7/2017 20:48:13", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 20:48:27", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 20:49:04", "False", "False", "True" , "False", "True" , "False", "True" , "False", "True" , "False", "True" , "False", "True" , "False" UNION
   SELECT "11/7/2017 20:49:30", "True" , "True" , "False", "False", "True" , "False", "False", "True" , "False", "False", "False", "True" , "True" , "False" UNION
   SELECT "11/7/2017 20:49:40", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/7/2017 20:50:37", "False", "True" , "False", "False", "False", "True" , "False", "True" , "False", "False", "True" , "True" , "False", "True"  UNION
   SELECT "11/7/2017 20:50:46", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 20:51:26", "False", "True" , "False", "False", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/7/2017 20:51:30", "False", "True" , "True" , "False", "True" , "False", "False", "False", "True" , "True" , "False", "True" , "False", "True"  UNION
   SELECT "11/7/2017 20:51:59", "True" , "True" , "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 20:52:10", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "True" , "False", "False", "False", "False" UNION
   SELECT "11/7/2017 20:52:11", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/7/2017 20:52:23", "False", "True" , "False", "True" , "False", "True" , "False", "True" , "False", "True" , "False", "True" , "False", "True"  UNION
   SELECT "11/7/2017 20:52:29", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/7/2017 20:53:16", "False", "False", "True" , "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 20:53:26", "False", "True" , "False", "True" , "True" , "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/7/2017 20:53:28", "True" , "False", "True" , "True" , "True" , "False", "True" , "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/7/2017 20:53:30", "False", "False", "False", "False", "False", "True" , "True" , "True" , "True" , "True" , "True" , "False", "False", "False" UNION
   SELECT "11/7/2017 20:53:57", "True" , "True" , "True" , "True" , "True" , "True" , "False", "True" , "True" , "False", "True" , "True" , "True" , "True"  UNION
   SELECT "11/7/2017 20:54:01", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "True" , "True" , "False" UNION
   SELECT "11/7/2017 20:54:05", "True" , "True" , "True" , "True" , "False", "False", "False", "False", "False", "False", "False", "True" , "True" , "True"  UNION
   SELECT "11/7/2017 20:54:52", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/7/2017 20:55:10", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/7/2017 20:55:18", "True" , "True" , "True" , "False", "False", "True" , "True" , "True" , "False", "False", "True" , "False", "False", "True"  UNION
   SELECT "11/7/2017 20:55:21", "True" , "True" , "True" , "False", "True" , "False", "False", "False", "True" , "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 20:55:25", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 20:55:29", "True" , "False", "False", "False", "False", "True" , "True" , "False", "False", "True" , "False", "True" , "False", "True"  UNION
   SELECT "11/7/2017 20:55:35", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/7/2017 20:56:17", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "True" , "False", "False", "False" UNION
   SELECT "11/7/2017 20:56:27", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/7/2017 20:56:50", "False", "True" , "False", "True" , "False", "False", "False", "True" , "True" , "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 20:56:57", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 20:57:09", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/7/2017 20:57:21", "True" , "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "True"  UNION
   SELECT "11/7/2017 20:57:26", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/7/2017 20:58:24", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "True" , "False", "False", "False", "False" UNION
   SELECT "11/7/2017 20:58:28", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "True"  UNION
   SELECT "11/7/2017 20:58:47", "True" , "False", "True" , "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 20:58:50", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/7/2017 20:59:02", "True" , "False", "False", "True" , "True" , "False", "False", "False", "False", "False", "True" , "True" , "True" , "False" UNION
   SELECT "11/7/2017 20:59:35", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 20:59:51", "False", "False", "False", "False", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/7/2017 21:00:11", "True" , "False", "False", "False", "False", "False", "False", "False", "True" , "True" , "False", "False", "False", "True"  UNION
   SELECT "11/7/2017 21:00:20", "False", "True" , "False", "True" , "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 21:01:24", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 21:01:59", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/7/2017 21:02:06", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 21:02:26", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 21:03:00", "False", "False", "False", "False", "False", "False", "True" , "True" , "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 21:03:21", "True" , "False", "True" , "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 21:03:28", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/7/2017 21:03:32", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "True" , "False", "False", "True" , "False" UNION
   SELECT "11/7/2017 21:03:43", "True" , "True" , "False", "False", "False", "False", "False", "False", "False", "False", "True" , "True" , "True" , "True"  UNION
   SELECT "11/7/2017 21:04:06", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "False", "True"  UNION
   SELECT "11/7/2017 21:04:41", "False", "False", "True" , "True" , "False", "False", "False", "True" , "False", "True" , "False", "False", "False", "True"  UNION
   SELECT "11/7/2017 21:04:57", "True" , "True" , "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 21:04:58", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 21:05:05", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/7/2017 21:05:05", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "True" , "False", "True"  UNION
   SELECT "11/7/2017 21:05:11", "True" , "True" , "True" , "False", "True" , "False", "False", "True" , "True" , "True" , "False", "False", "True" , "True"  UNION
   SELECT "11/7/2017 21:05:21", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/7/2017 21:05:39", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 21:06:22", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/7/2017 21:06:33", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 21:06:37", "False", "False", "True" , "True" , "False", "False", "True" , "False", "False", "False", "False", "True" , "True" , "False" UNION
   SELECT "11/7/2017 21:07:00", "False", "True" , "False", "False", "False", "False", "True" , "True" , "False", "False", "False", "True" , "True" , "False" UNION
   SELECT "11/7/2017 21:07:23", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 21:07:48", "False", "False", "False", "False", "False", "True" , "False", "True" , "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 21:08:12", "True" , "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/7/2017 21:08:13", "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 21:08:49", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "True" , "True" , "False" UNION
   SELECT "11/7/2017 21:09:52", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/7/2017 21:11:10", "False", "True" , "False", "True" , "True" , "True" , "False", "True" , "False", "False", "False", "True" , "False", "True"  UNION
   SELECT "11/7/2017 21:11:58", "True" , "True" , "True" , "False", "True" , "False", "True" , "False", "True" , "False", "True" , "False", "False", "False" UNION
   SELECT "11/7/2017 21:12:33", "True" , "True" , "False", "False", "True" , "False", "False", "True" , "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/7/2017 21:13:05", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/7/2017 21:13:13", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/7/2017 21:13:20", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/7/2017 21:14:24", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 21:15:37", "True" , "False", "False", "True" , "False", "False", "False", "True" , "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/7/2017 21:15:38", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/7/2017 21:17:26", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/7/2017 21:19:07", "True" , "True" , "True" , "True" , "True" , "False", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/7/2017 21:19:17", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/7/2017 21:19:42", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/7/2017 21:20:52", "False", "False", "False", "True" , "False", "False", "True" , "False", "False", "True" , "False", "False", "False", "True"  UNION
   SELECT "11/7/2017 21:21:27", "True" , "False", "True" , "False", "True" , "False", "True" , "False", "True" , "False", "True" , "False", "False", "True"  UNION
   SELECT "11/7/2017 21:21:30", "False", "False", "False", "False", "False", "True" , "True" , "False", "False", "False", "False", "False", "True" , "True"  UNION
   SELECT "11/7/2017 21:21:43", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/7/2017 21:22:02", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 21:22:03", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False" UNION
   SELECT "11/7/2017 21:22:14", "True" , "True" , "True" , "False", "True" , "False", "False", "False", "True" , "False", "True" , "False", "True" , "False" UNION
   SELECT "11/7/2017 21:22:37", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/7/2017 21:22:59", "False", "False", "True" , "False", "False", "True" , "True" , "False", "True" , "True" , "True" , "False", "False", "True"  UNION
   SELECT "11/7/2017 21:23:42", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 21:24:24", "False", "True" , "False", "False", "False", "False", "False", "False", "True" , "False", "False", "True" , "True" , "True"  UNION
   SELECT "11/7/2017 21:25:40", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 21:26:11", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/7/2017 21:26:53", "False", "False", "False", "True" , "False", "True" , "False", "False", "False", "False", "False", "False", "True" , "False" UNION
   SELECT "11/7/2017 21:27:31", "True" , "True" , "False", "True" , "False", "False", "False", "True" , "False", "False", "False", "True" , "False", "True"  UNION
   SELECT "11/7/2017 21:27:46", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "False", "False", "False" UNION
   SELECT "11/7/2017 21:28:04", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False" UNION
   SELECT "11/7/2017 21:29:41", "True" , "True" , "True" , "True" , "True" , "False", "False", "False", "False", "False", "False", "True" , "False", "True"  UNION
   SELECT "11/7/2017 21:33:07", "False", "True" , "False", "False", "True" , "False", "True" , "False", "False", "True" , "False", "True" , "False", "True"  UNION
   SELECT "11/7/2017 21:33:08", "False", "True" , "True" , "False", "False", "True" , "False", "True" , "False", "False", "False", "True" , "False", "True"  UNION
   SELECT "11/7/2017 21:34:38", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "True" , "True" , "False" UNION
   SELECT "11/7/2017 21:34:45", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False" UNION
   SELECT "11/7/2017 21:36:21", "False", "False", "False", "False", "False", "True" , "False", "True" , "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 21:36:33", "True" , "True" , "True" , "True" , "False", "False", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/7/2017 21:37:54", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/7/2017 21:38:13", "True" , "True" , "False", "True" , "False", "False", "False", "True" , "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/7/2017 21:38:28", "False", "False", "True" , "False", "False", "True" , "False", "True" , "False", "False", "False", "True" , "True" , "False" UNION
   SELECT "11/7/2017 21:39:52", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "True" , "False", "False", "True"  UNION
   SELECT "11/7/2017 21:40:13", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/7/2017 21:41:27", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/7/2017 21:44:04", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "True" , "False", "False", "False", "False" UNION
   SELECT "11/7/2017 21:44:37", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False" UNION
   SELECT "11/7/2017 21:44:57", "True" , "True" , "True" , "True" , "False", "True" , "False", "True" , "True" , "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 21:47:10", "False", "False", "True" , "True" , "False", "True" , "False", "True" , "False", "False", "False", "True" , "False", "True"  UNION
   SELECT "11/7/2017 21:47:24", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/7/2017 21:47:56", "False", "False", "False", "True" , "False", "False", "True" , "False", "False", "True" , "False", "False", "False", "False" UNION
   SELECT "11/7/2017 21:50:36", "False", "True" , "False", "False", "True" , "False", "False", "False", "True" , "False", "False", "False", "True" , "False" UNION
   SELECT "11/7/2017 21:50:56", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/7/2017 21:51:25", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 21:51:59", "True" , "True" , "True" , "True" , "False", "True" , "False", "False", "True" , "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 21:52:06", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "True" , "False", "False", "False", "False" UNION
   SELECT "11/7/2017 21:52:32", "True" , "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 21:53:04", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "True"  UNION
   SELECT "11/7/2017 21:53:36", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/7/2017 21:53:59", "False", "False", "False", "False", "False", "True" , "False", "False", "True" , "False", "False", "True" , "True" , "False" UNION
   SELECT "11/7/2017 21:54:43", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "True" , "False", "False", "False", "False" UNION
   SELECT "11/7/2017 21:54:53", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "True" , "True"  UNION
   SELECT "11/7/2017 21:57:02", "False", "True" , "False", "False", "True" , "False", "True" , "False", "True" , "False", "True" , "False", "True" , "False" UNION
   SELECT "11/7/2017 21:57:02", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/7/2017 21:57:06", "True" , "False", "True" , "False", "False", "True" , "False", "True" , "False", "False", "False", "True" , "False", "True"  UNION
   SELECT "11/7/2017 21:58:37", "False", "True" , "False", "True" , "False", "True" , "False", "True" , "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/7/2017 21:58:51", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/7/2017 21:59:23", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False" UNION
   SELECT "11/7/2017 21:59:27", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "True" , "True"  UNION
   SELECT "11/7/2017 22:00:56", "False", "True" , "False", "False", "True" , "False", "False", "False", "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/7/2017 22:01:30", "True" , "False", "True" , "False", "True" , "False", "False", "True" , "False", "False", "True" , "False", "True" , "True"  UNION
   SELECT "11/7/2017 22:02:15", "False", "False", "True" , "False", "True" , "False", "False", "True" , "False", "True" , "False", "False", "False", "False" UNION
   SELECT "11/7/2017 22:02:25", "True" , "True" , "True" , "False", "True" , "True" , "False", "False", "False", "False", "True" , "True" , "False", "True"  UNION
   SELECT "11/7/2017 22:03:09", "False", "True" , "False", "False", "True" , "False", "False", "False", "False", "True" , "False", "False", "False", "True"  UNION
   SELECT "11/7/2017 22:04:45", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 22:05:38", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 22:05:55", "True" , "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "True" , "False" UNION
   SELECT "11/7/2017 22:07:34", "True" , "False", "True" , "False", "True" , "False", "True" , "False", "True" , "False", "True" , "False", "True" , "False" UNION
   SELECT "11/7/2017 22:07:48", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "True" , "True" , "False" UNION
   SELECT "11/7/2017 22:08:12", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "True" , "True" , "True" , "False" UNION
   SELECT "11/7/2017 22:08:42", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False" UNION
   SELECT "11/7/2017 22:09:16", "False", "False", "True" , "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 22:10:05", "False", "True" , "True" , "True" , "False", "True" , "False", "False", "True" , "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 22:10:07", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 22:10:37", "False", "False", "False", "True" , "False", "False", "False", "True" , "False", "False", "True" , "False", "False", "False" UNION
   SELECT "11/7/2017 22:10:42", "True" , "True" , "False", "True" , "False", "True" , "False", "True" , "True" , "False", "True" , "False", "True" , "True"  UNION
   SELECT "11/7/2017 22:13:05", "False", "False", "False", "False", "False", "True" , "False", "True" , "True" , "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 22:13:23", "True" , "False", "False", "True" , "False", "False", "False", "True" , "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/7/2017 22:14:42", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 22:15:05", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "True"  UNION
   SELECT "11/7/2017 22:17:06", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "False", "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/7/2017 22:17:42", "True" , "False", "True" , "True" , "False", "True" , "False", "True" , "True" , "True" , "False", "True" , "False", "True"  UNION
   SELECT "11/7/2017 22:18:38", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/7/2017 22:19:24", "False", "True" , "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/7/2017 22:19:33", "True" , "True" , "True" , "False", "True" , "True" , "False", "True" , "True" , "False", "True" , "True" , "False", "True"  UNION
   SELECT "11/7/2017 22:19:52", "True" , "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 22:20:00", "True" , "True" , "True" , "False", "False", "False", "False", "True" , "False", "True" , "True" , "False", "False", "False" UNION
   SELECT "11/7/2017 22:20:11", "False", "True" , "False", "True" , "True" , "True" , "True" , "False", "False", "False", "False", "True" , "True" , "True"  UNION
   SELECT "11/7/2017 22:21:26", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False" UNION
   SELECT "11/7/2017 22:22:11", "True" , "False", "True" , "False", "True" , "False", "True" , "False", "False", "True" , "True" , "True" , "False", "False" UNION
   SELECT "11/7/2017 22:23:33", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/7/2017 22:25:32", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "True" , "True" , "False", "False" UNION
   SELECT "11/7/2017 22:26:42", "True" , "True" , "True" , "True" , "False", "True" , "False", "False", "True" , "False", "False", "True" , "False", "False" UNION
   SELECT "11/7/2017 22:30:01", "True" , "False", "True" , "False", "False", "False", "True" , "False", "False", "True" , "False", "True" , "False", "True"  UNION
   SELECT "11/7/2017 22:32:00", "False", "False", "False", "False", "True" , "False", "True" , "True" , "False", "False", "True" , "True" , "False", "False" UNION
   SELECT "11/7/2017 22:33:17", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/7/2017 22:35:18", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/7/2017 22:36:25", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 22:36:33", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "True" , "True"  UNION
   SELECT "11/7/2017 22:36:44", "True" , "True" , "True" , "True" , "True" , "True" , "False", "True" , "True" , "True" , "True" , "False", "False", "True"  UNION
   SELECT "11/7/2017 22:37:45", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/7/2017 22:40:47", "False", "True" , "False", "True" , "False", "False", "False", "True" , "False", "False", "False", "True" , "True" , "False" UNION
   SELECT "11/7/2017 22:41:03", "False", "False", "True" , "False", "True" , "False", "False", "True" , "False", "False", "True" , "False", "True" , "False" UNION
   SELECT "11/7/2017 22:43:36", "True" , "True" , "True" , "False", "False", "False", "True" , "False", "False", "False", "True" , "False", "False", "True"  UNION
   SELECT "11/7/2017 22:44:08", "True" , "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/7/2017 22:47:03", "True" , "False", "True" , "False", "True" , "False", "True" , "False", "True" , "False", "True" , "False", "False", "False" UNION
   SELECT "11/7/2017 22:47:57", "False", "True" , "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "True" , "True"  UNION
   SELECT "11/7/2017 22:48:21", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "True"  UNION
   SELECT "11/7/2017 22:49:03", "True" , "True" , "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "True" , "True"  UNION
   SELECT "11/7/2017 22:49:35", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 22:52:44", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 22:54:22", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False" UNION
   SELECT "11/7/2017 22:54:48", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "False", "False", "False", "False" UNION
   SELECT "11/7/2017 22:55:42", "False", "False", "False", "True" , "False", "False", "False", "True" , "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/7/2017 22:56:03", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "True" , "False", "False", "False", "False" UNION
   SELECT "11/7/2017 22:56:41", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "True" , "False", "True"  UNION
   SELECT "11/7/2017 22:57:12", "False", "True" , "False", "False", "False", "True" , "False", "True" , "False", "False", "False", "True" , "True" , "True"  UNION
   SELECT "11/7/2017 22:57:37", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/7/2017 22:59:15", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "True"  UNION
   SELECT "11/7/2017 23:00:25", "False", "True" , "False", "True" , "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 23:01:52", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/7/2017 23:04:09", "False", "False", "False", "False", "True" , "True" , "False", "False", "False", "True" , "True" , "True" , "False", "True"  UNION
   SELECT "11/7/2017 23:04:26", "True" , "True" , "False", "False", "False", "True" , "True" , "False", "True" , "False", "True" , "False", "False", "True"  UNION
   SELECT "11/7/2017 23:08:30", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/7/2017 23:08:49", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "True" , "False", "False" UNION
   SELECT "11/7/2017 23:10:06", "False", "True" , "False", "True" , "False", "True" , "False", "True" , "False", "True" , "False", "True" , "False", "True"  UNION
   SELECT "11/7/2017 23:10:39", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 23:12:07", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/7/2017 23:16:13", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/7/2017 23:17:49", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 23:18:54", "True" , "True" , "False", "False", "False", "True" , "False", "True" , "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/7/2017 23:19:39", "True" , "False", "False", "True" , "True" , "True" , "False", "True" , "True" , "False", "False", "True" , "False", "True";

CREATE TABLE checkboxes_pt2 AS
   SELECT "11/7/2017 23:20:00" AS time, "False" AS "0", "False" AS "1", "False" AS "2", "True" AS "3", "False" AS "4", "True" AS "5", "False" AS "6", "False" AS "7", "True" AS "8" , "False" AS "9", "False" AS "10", "True" AS "2017" , "False" AS "9000", "True" AS "9001" UNION
   SELECT "11/7/2017 23:20:58", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "False", "False" UNION
   SELECT "11/7/2017 23:21:01", "False", "True" , "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 23:24:30", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 23:25:53", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "False", "False", "False" UNION
   SELECT "11/7/2017 23:29:39", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/7/2017 23:33:32", "False", "True" , "True" , "False", "False", "True" , "False", "False", "True" , "False", "False", "True" , "True" , "True"  UNION
   SELECT "11/7/2017 23:34:42", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/7/2017 23:38:21", "True" , "False", "True" , "True" , "True" , "False", "False", "True" , "False", "True" , "False", "True" , "True" , "True"  UNION
   SELECT "11/7/2017 23:38:32", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/7/2017 23:39:28", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "True" , "False", "False", "False" UNION
   SELECT "11/7/2017 23:40:16", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 23:40:43", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 23:42:06", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 23:43:31", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/7/2017 23:43:45", "False", "False", "True" , "False", "False", "False", "True" , "False", "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/7/2017 23:46:37", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "False", "False", "True" , "False", "True" , "False", "False" UNION
   SELECT "11/7/2017 23:47:08", "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False" UNION
   SELECT "11/7/2017 23:47:11", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/7/2017 23:49:20", "True" , "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/7/2017 23:54:31", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/7/2017 23:57:12", "False", "True" , "False", "True" , "False", "False", "False", "True" , "False", "False", "False", "False", "True" , "False" UNION
   SELECT "11/7/2017 23:59:07", "True" , "True" , "True" , "False", "False", "True" , "False", "False", "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/8/2017 0:00:46" , "True" , "True" , "True" , "True" , "True" , "False", "False", "True" , "True" , "False", "True" , "False", "False", "True"  UNION
   SELECT "11/8/2017 0:00:46" , "False", "False", "True" , "False", "False", "True" , "False", "False", "False", "True" , "False", "False", "False", "True"  UNION
   SELECT "11/8/2017 0:01:43" , "True" , "True" , "True" , "False", "True" , "True" , "False", "True" , "False", "True" , "False", "True" , "True" , "False" UNION
   SELECT "11/8/2017 0:04:27" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/8/2017 0:06:41" , "True" , "False", "False", "True" , "True" , "False", "True" , "False", "True" , "False", "False", "False", "True" , "False" UNION
   SELECT "11/8/2017 0:11:31" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/8/2017 0:11:31" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/8/2017 0:15:29" , "False", "False", "False", "True" , "False", "False", "False", "True" , "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/8/2017 0:18:04" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/8/2017 0:18:56" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/8/2017 0:24:50" , "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/8/2017 0:25:27" , "True" , "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "True" , "False" UNION
   SELECT "11/8/2017 0:25:32" , "True" , "False", "False", "False", "False", "True" , "False", "True" , "False", "False", "False", "False", "True" , "True"  UNION
   SELECT "11/8/2017 0:27:02" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "False", "True" , "True" , "True" , "False", "True" , "False" UNION
   SELECT "11/8/2017 0:30:37" , "True" , "True" , "False", "True" , "False", "True" , "False", "False", "True" , "False", "True" , "True" , "False", "True"  UNION
   SELECT "11/8/2017 0:32:57" , "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/8/2017 0:35:02" , "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/8/2017 0:35:09" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/8/2017 0:36:43" , "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/8/2017 0:37:17" , "False", "False", "True" , "False", "False", "True" , "False", "True" , "False", "False", "False", "False", "True" , "True"  UNION
   SELECT "11/8/2017 0:39:41" , "False", "False", "True" , "False", "True" , "False", "True" , "False", "True" , "False", "True" , "True" , "False", "False" UNION
   SELECT "11/8/2017 0:45:11" , "True" , "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/8/2017 0:47:00" , "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "True" , "False", "True"  UNION
   SELECT "11/8/2017 0:47:28" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/8/2017 0:49:18" , "True" , "True" , "True" , "False", "True" , "False", "False", "True" , "False", "False", "False", "True" , "False", "True"  UNION
   SELECT "11/8/2017 0:52:57" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "True" , "True"  UNION
   SELECT "11/8/2017 0:54:38" , "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/8/2017 0:56:18" , "True" , "True" , "True" , "True" , "True" , "False", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/8/2017 1:05:21" , "False", "False", "False", "False", "True" , "False", "False", "True" , "False", "True" , "True" , "True" , "True" , "False" UNION
   SELECT "11/8/2017 1:08:29" , "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/8/2017 1:22:43" , "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/8/2017 1:27:42" , "True" , "True" , "True" , "False", "False", "False", "False", "True" , "False", "False", "False", "True" , "False", "True"  UNION
   SELECT "11/8/2017 1:28:01" , "True" , "False", "False", "False", "False", "True" , "True" , "False", "False", "True" , "False", "False", "True" , "True"  UNION
   SELECT "11/8/2017 1:32:56" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/8/2017 1:33:53" , "False", "True" , "True" , "False", "False", "False", "False", "True" , "True" , "False", "False", "True" , "True" , "True"  UNION
   SELECT "11/8/2017 1:34:43" , "False", "True" , "True" , "True" , "True" , "True" , "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/8/2017 1:36:09" , "True" , "True" , "True" , "True" , "True" , "False", "False", "False", "False", "False", "False", "False", "True" , "True"  UNION
   SELECT "11/8/2017 1:43:40" , "False", "True" , "False", "False", "False", "False", "False", "True" , "False", "False", "False", "True" , "False", "True"  UNION
   SELECT "11/8/2017 1:52:42" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/8/2017 2:01:27" , "True" , "True" , "False", "True" , "False", "False", "False", "False", "False", "True" , "False", "True" , "False", "True"  UNION
   SELECT "11/8/2017 2:17:34" , "True" , "False", "True" , "False", "False", "True" , "False", "False", "True" , "False", "False", "True" , "True" , "True"  UNION
   SELECT "11/8/2017 2:41:52" , "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/8/2017 2:46:00" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/8/2017 2:47:55" , "True" , "True" , "True" , "True" , "True" , "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/8/2017 3:03:09" , "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/8/2017 3:05:37" , "False", "False", "False", "False", "True" , "False", "False", "False", "True" , "False", "False", "False", "True" , "False" UNION
   SELECT "11/8/2017 3:11:25" , "True" , "True" , "True" , "True" , "False", "True" , "False", "False", "True" , "False", "False", "True" , "True" , "False" UNION
   SELECT "11/8/2017 6:00:48" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False" UNION
   SELECT "11/8/2017 7:00:08" , "False", "True" , "False", "True" , "True" , "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/8/2017 7:13:09" , "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/8/2017 7:16:54" , "True" , "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/8/2017 7:27:31" , "True" , "False", "False", "False", "True" , "False", "False", "True" , "False", "False", "True" , "True" , "False", "True"  UNION
   SELECT "11/8/2017 7:55:16" , "True" , "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "True" , "True" , "True"  UNION
   SELECT "11/8/2017 8:09:34" , "True" , "False", "True" , "True" , "False", "True" , "True" , "True" , "True" , "True" , "True" , "False", "False", "False" UNION
   SELECT "11/8/2017 8:10:34" , "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False" UNION
   SELECT "11/8/2017 8:17:30" , "False", "False", "True" , "True" , "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/8/2017 8:20:49" , "False", "False", "True" , "False", "False", "False", "True" , "True" , "True" , "False", "True" , "True" , "False", "True"  UNION
   SELECT "11/8/2017 8:24:39" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/8/2017 8:25:07" , "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/8/2017 8:31:22" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/8/2017 8:32:43" , "False", "False", "True" , "True" , "False", "False", "False", "True" , "False", "False", "False", "True" , "True" , "True"  UNION
   SELECT "11/8/2017 8:39:57" , "True" , "False", "True" , "False", "False", "False", "True" , "False", "False", "False", "True" , "True" , "False", "True"  UNION
   SELECT "11/8/2017 8:42:56" , "True" , "False", "True" , "False", "True" , "False", "False", "False", "False", "True" , "False", "False", "True" , "False" UNION
   SELECT "11/8/2017 8:44:31" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False" UNION
   SELECT "11/8/2017 8:50:16" , "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/8/2017 8:50:46" , "False", "False", "True" , "True" , "False", "True" , "False", "True" , "False", "False", "False", "True" , "False", "True"  UNION
   SELECT "11/8/2017 8:54:21" , "True" , "False", "False", "False", "False", "False", "False", "False", "True" , "False", "True" , "False", "False", "False" UNION
   SELECT "11/8/2017 8:58:59" , "False", "False", "False", "True" , "False", "False", "False", "True" , "False", "True" , "False", "False", "True" , "True"  UNION
   SELECT "11/8/2017 9:10:16" , "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/8/2017 9:10:58" , "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/8/2017 9:15:11" , "False", "False", "True" , "False", "False", "True" , "False", "True" , "False", "True" , "False", "False", "False", "False" UNION
   SELECT "11/8/2017 9:17:14" , "True" , "False", "True" , "True" , "False", "False", "True" , "False", "False", "True" , "False", "True" , "False", "True"  UNION
   SELECT "11/8/2017 9:21:34" , "False", "False", "False", "False", "True" , "False", "False", "True" , "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/8/2017 9:29:27" , "False", "False", "True" , "True" , "True" , "False", "True" , "False", "True" , "True" , "False", "False", "False", "False" UNION
   SELECT "11/8/2017 9:31:05" , "False", "False", "True" , "False", "False", "False", "False", "True" , "False", "False", "True" , "True" , "False", "False" UNION
   SELECT "11/8/2017 9:35:16" , "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/8/2017 9:45:58" , "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "True" , "True"  UNION
   SELECT "11/8/2017 9:49:58" , "False", "False", "False", "False", "False", "False", "True" , "False", "False", "True" , "False", "False", "False", "False" UNION
   SELECT "11/8/2017 9:56:41" , "False", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/8/2017 10:11:54", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "True" , "False", "False", "False", "False" UNION
   SELECT "11/8/2017 10:12:56", "True" , "False", "False", "False", "False", "True" , "False", "False", "False", "False", "True" , "True" , "False", "False" UNION
   SELECT "11/8/2017 10:14:49", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/8/2017 10:15:07", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/8/2017 10:31:11", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "False" UNION
   SELECT "11/8/2017 10:33:01", "False", "True" , "True" , "True" , "False", "True" , "False", "False", "True" , "False", "False", "False", "False", "False" UNION
   SELECT "11/8/2017 10:33:36", "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/8/2017 10:41:40", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/8/2017 10:43:16", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/8/2017 10:44:37", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/8/2017 10:50:27", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/8/2017 10:52:20", "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/8/2017 10:56:15", "True" , "True" , "True" , "True" , "True" , "True" , "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/8/2017 10:57:42", "True" , "False", "True" , "False", "False", "True" , "False", "True" , "True" , "False", "False", "True" , "False", "True"  UNION
   SELECT "11/8/2017 11:07:23", "True" , "False", "False", "False", "False", "True" , "False", "False", "False", "True" , "False", "False", "False", "True"  UNION
   SELECT "11/8/2017 11:09:04", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/8/2017 11:10:54", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "True" , "True"  UNION
   SELECT "11/8/2017 11:12:36", "False", "True" , "False", "True" , "False", "False", "True" , "True" , "False", "False", "True" , "True" , "True" , "True"  UNION
   SELECT "11/8/2017 11:13:47", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "False", "False", "False" UNION
   SELECT "11/8/2017 11:15:26", "False", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "False", "False", "True"  UNION
   SELECT "11/8/2017 11:15:31", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "True" , "True" , "True" , "False" UNION
   SELECT "11/8/2017 11:16:14", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/8/2017 11:20:55", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/8/2017 11:26:35", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/8/2017 11:31:13", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "True"  UNION
   SELECT "11/8/2017 11:33:39", "False", "False", "True" , "True" , "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/8/2017 11:34:58", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "True" , "False", "True"  UNION
   SELECT "11/8/2017 11:35:16", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/8/2017 11:35:31", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/8/2017 11:39:46", "True" , "True" , "True" , "False", "False", "False", "False", "True" , "False", "True" , "False", "True" , "False", "False" UNION
   SELECT "11/8/2017 11:40:34", "False", "False", "False", "False", "False", "False", "True" , "False", "True" , "True" , "False", "True" , "False", "False" UNION
   SELECT "11/8/2017 11:48:30", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "False", "True"  UNION
   SELECT "11/8/2017 11:50:37", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/8/2017 11:57:36", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/8/2017 11:58:00", "True" , "True" , "False", "False", "True" , "True" , "False", "False", "False", "False", "False", "True" , "False", "True"  UNION
   SELECT "11/8/2017 12:06:45", "True" , "False", "False", "False", "False", "False", "False", "False", "True" , "False", "True" , "True" , "True" , "True"  UNION
   SELECT "11/8/2017 12:20:27", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/8/2017 12:31:57", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/8/2017 12:34:06", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "True"  UNION
   SELECT "11/8/2017 12:34:17", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/8/2017 12:40:23", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/8/2017 12:42:49", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "True"  UNION
   SELECT "11/8/2017 12:55:17", "True" , "True" , "False", "False", "True" , "False", "True" , "False", "True" , "True" , "True" , "False", "False", "False" UNION
   SELECT "11/8/2017 13:06:36", "False", "True" , "True" , "True" , "False", "True" , "False", "True" , "False", "False", "False", "True" , "False", "True"  UNION
   SELECT "11/8/2017 13:09:09", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/8/2017 13:13:26", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/8/2017 13:21:51", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "False", "True" , "True"  UNION
   SELECT "11/8/2017 13:30:12", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/8/2017 13:38:51", "False", "False", "True" , "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/8/2017 13:49:04", "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/8/2017 14:05:33", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False" UNION
   SELECT "11/8/2017 14:15:30", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/8/2017 14:16:04", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/8/2017 14:28:04", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/8/2017 14:35:23", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/8/2017 14:35:49", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/8/2017 14:38:07", "False", "False", "True" , "False", "False", "False", "True" , "True" , "True" , "False", "True" , "True" , "True" , "True"  UNION
   SELECT "11/8/2017 14:43:51", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/8/2017 14:48:58", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/8/2017 15:15:15", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/8/2017 15:39:42", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/8/2017 16:02:26", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/8/2017 16:18:38", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "False", "False", "False" UNION
   SELECT "11/8/2017 16:37:46", "False", "True" , "False", "False", "False", "False", "True" , "False", "False", "False", "False", "True" , "False", "True"  UNION
   SELECT "11/8/2017 16:58:48", "False", "True" , "True" , "False", "True" , "False", "True" , "True" , "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/8/2017 17:15:30", "False", "True" , "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/8/2017 17:17:56", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/8/2017 17:27:27", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/8/2017 17:31:42", "False", "False", "False", "False", "False", "True" , "True" , "True" , "True" , "False", "False", "False", "False", "True"  UNION
   SELECT "11/8/2017 17:33:14", "True" , "True" , "True" , "False", "False", "False", "False", "True" , "True" , "False", "False", "True" , "False", "True"  UNION
   SELECT "11/8/2017 17:50:02", "True" , "True" , "False", "False", "False", "False", "False", "False", "False", "True" , "True" , "False", "True" , "True"  UNION
   SELECT "11/8/2017 17:50:11", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/8/2017 17:50:19", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/8/2017 18:20:22", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "True" , "False", "False", "False", "False" UNION
   SELECT "11/8/2017 18:22:40", "True" , "False", "False", "True" , "True" , "False", "False", "False", "False", "False", "False", "True" , "True" , "False" UNION
   SELECT "11/8/2017 18:51:29", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/8/2017 18:58:06", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/8/2017 19:05:42", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False" UNION
   SELECT "11/8/2017 19:16:25", "True" , "False", "True" , "True" , "True" , "False", "True" , "False", "False", "True" , "True" , "False", "True" , "True"  UNION
   SELECT "11/8/2017 19:28:08", "True" , "True" , "True" , "True" , "True" , "True" , "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/8/2017 19:58:50", "False", "False", "False", "True" , "True" , "False", "False", "False", "True" , "True" , "False", "False", "True" , "True"  UNION
   SELECT "11/8/2017 20:00:58", "True" , "False", "True" , "False", "True" , "True" , "True" , "False", "True" , "False", "True" , "True" , "True" , "False" UNION
   SELECT "11/8/2017 20:10:14", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "True" , "False" UNION
   SELECT "11/8/2017 20:29:54", "True" , "False", "True" , "False", "True" , "False", "True" , "False", "True" , "False", "False", "True" , "True" , "True"  UNION
   SELECT "11/8/2017 20:46:36", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/8/2017 20:48:14", "True" , "True" , "True" , "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/8/2017 21:04:16", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/8/2017 21:11:38", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "True" , "False", "False", "False", "False" UNION
   SELECT "11/8/2017 22:01:58", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/8/2017 22:13:55", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False" UNION
   SELECT "11/8/2017 22:29:11", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/8/2017 23:04:49", "False", "False", "False", "False", "True" , "False", "True" , "False", "True" , "False", "False", "True" , "False", "False" UNION
   SELECT "11/8/2017 23:11:14", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "True" , "False", "False", "False", "False" UNION
   SELECT "11/8/2017 23:12:42", "True" , "True" , "False", "False", "False", "False", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/8/2017 23:24:19", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "True" , "False", "True" , "False", "True"  UNION
   SELECT "11/8/2017 23:40:43", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "True"  UNION
   SELECT "11/9/2017 0:14:41" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/9/2017 0:20:28" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False" UNION
   SELECT "11/9/2017 0:25:52" , "False", "False", "False", "False", "True" , "True" , "True" , "True" , "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/9/2017 0:44:51" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/9/2017 0:55:21" , "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "True" , "True" , "False" UNION
   SELECT "11/9/2017 1:20:56" , "False", "True" , "False", "True" , "False", "False", "False", "True" , "False", "False", "False", "True" , "False", "True"  UNION
   SELECT "11/9/2017 2:25:44" , "False", "True" , "False", "True" , "True" , "True" , "False", "False", "False", "True" , "False", "False", "False", "False" UNION
   SELECT "11/9/2017 2:37:48" , "False", "True" , "False", "True" , "True" , "False", "False", "True" , "False", "False", "False", "True" , "False", "True"  UNION
   SELECT "11/9/2017 8:04:24" , "False", "True" , "False", "False", "True" , "False", "False", "True" , "False", "False", "True" , "False", "False", "False" UNION
   SELECT "11/9/2017 8:49:41" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/9/2017 8:56:05" , "False", "False", "True" , "False", "False", "False", "True" , "False", "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/9/2017 10:36:53", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/9/2017 11:37:22", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "False", "True"  UNION
   SELECT "11/9/2017 12:00:14", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/9/2017 13:30:14", "True" , "True" , "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False" UNION
   SELECT "11/9/2017 13:41:39", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/9/2017 14:38:44", "True" , "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/9/2017 15:11:08", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/9/2017 17:02:25", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "True" , "True" , "False" UNION
   SELECT "11/9/2017 17:27:47", "True" , "True" , "False", "True" , "False", "False", "False", "True" , "False", "True" , "False", "True" , "False", "False" UNION
   SELECT "11/9/2017 17:39:21", "False", "False", "True" , "True" , "False", "False", "False", "True" , "False", "False", "False", "False", "True" , "False" UNION
   SELECT "11/9/2017 17:51:50", "False", "False", "False", "False", "True" , "False", "False", "True" , "False", "False", "False", "True" , "False", "True"  UNION
   SELECT "11/9/2017 17:52:24", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "True"  UNION
   SELECT "11/9/2017 18:26:01", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "True" , "False", "False", "True" , "False" UNION
   SELECT "11/9/2017 18:51:20", "True" , "False", "True" , "False", "True" , "True" , "True" , "False", "False", "True" , "False", "False", "True" , "True"  UNION
   SELECT "11/9/2017 19:58:28", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/9/2017 22:47:03", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False" UNION
   SELECT "11/10/2017 0:01:44", "False", "False", "False", "True" , "True" , "True" , "False", "False", "False", "True" , "False", "True" , "True" , "False" UNION
   SELECT "11/10/2017 0:10:37", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False" UNION
   SELECT "11/10/2017 0:14:55", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "True" , "False", "False", "False", "False" UNION
   SELECT "11/10/2017 0:31:41", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False" UNION
   SELECT "11/10/2017 1:06:53", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True"  UNION
   SELECT "11/10/2017 12:17:08", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "11/10/2017 16:58:19", "True" , "False", "True" , "True" , "False", "True" , "True" , "True" , "False", "False", "False", "True" , "False", "True"  UNION
   SELECT "11/10/2017 17:51:33", "True" , "False", "False", "True" , "False", "False", "False", "True" , "False", "False", "True" , "True" , "False", "False" UNION
   SELECT "11/10/2017 17:56:28", "True" , "True" , "True" , "True" , "False", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "False", "True"  UNION
   SELECT "11/10/2017 18:51:30", "False", "False", "True" , "False", "True" , "False", "False", "False", "False", "False", "False", "True" , "True" , "True"  ;

CREATE TABLE fa17checkboxes AS
   SELECT * FROM checkboxes_pt1 UNION
   SELECT * FROM checkboxes_pt2;