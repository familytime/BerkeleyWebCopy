from threading import Thread, Lock
import random
import time

def main():
    xs = []

    def race():
        x = 10
        s = Lock()
        def do_stuff():
            time.sleep(random.random()/1000)
        def double():
            nonlocal x
            do_stuff()
            s.acquire()
            y = x
            do_stuff()
            x = y * 2
            s.release()
        def inc():
            nonlocal x
            do_stuff()
            s.acquire()
            y = x
            do_stuff()
            x = y + 1
            s.release()
        a = Thread(target=double)
        b = Thread(target=inc)
        a.start()
        b.start()
        a.join()
        b.join()
        xs.append(x)

    for _ in range(1000):
        race()

    from collections import Counter
    print(Counter(xs))

if __name__ == '__main__':
    main()
