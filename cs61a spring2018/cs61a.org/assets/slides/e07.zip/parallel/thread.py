import string
import threading
import urllib.request as request
from datetime import datetime

wiki = 'http://en.wikipedia.org/wiki/'

def main():
    start = datetime.now()

    def load(topic):
        content = request.urlopen(wiki + topic).read()
        print(topic, 'has length', len(content))

    ts = []

    for letter in string.ascii_letters:
        #load(letter)
        t = threading.Thread(target=load, args=(letter,))
        #t.run()
        t.start()
        ts.append(t)

    [t.join() for t in ts]

    print(datetime.now() - start)

if __name__ == '__main__':
    main()
