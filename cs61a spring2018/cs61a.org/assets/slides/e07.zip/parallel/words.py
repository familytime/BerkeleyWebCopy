from trie import trie
import flask
import requests
import threading

app = flask.Flask(__name__)

@app.route("/")
def main():
    return open('words.html').read()

@app.route("/extend/<prefix>")
def extend(prefix):
    words = trie.lookup(prefix)[:10]
    return flask.jsonify({'words': words})

@app.route("/load")
def load():
    pages = {}
    def load(word):
        r = requests.get('http://en.wikipedia.org/wiki/' + word)
        pages[word] = r.text
    words = flask.request.args.getlist('word')
    threads = []
    print('starting', len(words))
    for word in words:
        #load(word)
        t = threading.Thread(target=load, args=(word,))
        t.start()
        threads.append(t)
    [t.join() for t in threads]
    print('returning', len(pages))
    return flask.jsonify({'pages': pages})

if __name__=="__main__":
    app.run(debug=True)
