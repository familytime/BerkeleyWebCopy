//go:binary-only-package

package memoizer

import (
	"fmt"
	"hash/crc64"

	proj5 "github.com/61c-teach/sp18-proj5"
)
