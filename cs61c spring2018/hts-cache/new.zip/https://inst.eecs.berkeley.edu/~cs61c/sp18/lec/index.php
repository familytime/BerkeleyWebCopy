
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="CS61C Spring 2018 Discussion">
    <meta name="author" content="Justin Hsia">
    <link rel="icon" href="../../img/icon3.png">

    <title>CS61C Spring 2018: Great Ideas in Computer Architecture</title>
    

    <!-- Bootstrap core CSS -->
    <link href="../../bootstrap-dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="../../css/navbar-fixed-top.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <!-- Custom styles for Full Calendar integration -->
    <link href='../../fullcalendar/fullcalendar.css' rel='stylesheet' />
    <link href='../../fullcalendar/fullcalendar.print.css' rel='stylesheet' media='print' />
    <!-- Scripts for Full Calendar found in pagefooter.html -->

    <style>
        #loading {
            display: none;
            position: absolute;
            top: 10px;
            right: 10px;
        }
        #week-cal {
            max-width: 98%;
            margin: 0 auto;
        }
    </style>

  </head>

  <body data-spy="scroll" data-target="#navscroll">

    <!-- Fixed navbar -->
    <div id="navscroll">
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="../../" style="color: #000;">CS61C Spring 2018</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse" >
          <ul class="nav navbar-nav">
              <!-- anything here with an id starting with na will have a 
              ./ prepended on certain pages -->
              <!--            <li class="active"><a href="#">Home</a></li>-->
            <li><a id="na1" href="#announcements" >Announcements</a></li>
            <li><a id="na2" href="#calendar">Calendar</a></li>
            <!--            <li><a href="#officehours">Office Hours</a></li>-->
            <li><a id="na3" href="#sched">Weekly Schedule</a></li>

<!--            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Resources <span class="caret"></span></a>
              <ul class="dropdown-menu" role="menu">
                <li><a href="#">MIPS Green Sheet</a></li>
                <li><a href="#">GDB Reference Card</a></li>
                <li><a href="#">Harvey notes on C</a></li>
                <li class="divider"></li>
                <li class="dropdown-header">Nav header</li>
                <li><a href="#">Separated link</a></li>
                <li><a href="#">One more separated link</a></li>
              </ul>
            </li>-->
          </ul>
          <ul class="nav navbar-nav navbar-right">
            <li><a id="na5" href="#resources">Resources</a></li>
            <li id="stafnavbutton"><a id="na4" href="staff.php">Staff</a></li>
            <li id="polnavbutton"><a id="na6" href="policies.php">Policies</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>
    </div>

      <!-- Main component for a primary marketing message or call to action -->
        <div class="jumbotron" style="background-image: url('../../img/dphoto2_web.jpg'); background-size: 100%; margin-top:-20px;">
            <div class="container">
            <div class="row"   style="background-color:rgba(255,255,255,0.95);border-radius: 7px;"   >

                <div id="floatdiv2">
                    <div class="col-md-12" >
                        <div style="padding: 10px;">
                            <h2>Great Ideas in Computer Architecture (Machine Structures) </h2>
                            <h3><a href="http://eecs.berkeley.edu">UC Berkeley EECS</a></h3>
                            <h3>TuTh 3:30-5pm, <a href="http://www.berkeley.edu/map?mlk">Pauley Ballroom</a></h3>
                            <h3>Instructors: <a href="http://bnrg.cs.berkeley.edu/~randy/">Randy Katz</a>, <a href="https://people.eecs.berkeley.edu/~krste/">Krste Asanovic</a></h3>
                        </div>
                    </div>
                </div>

                <div id="floatdiv">
                    <div class="col-md-6" >
                        <div style="padding: 10px;">
                        <h2>Great Ideas in Computer Architecture (Machine Structures) </h2>
                        <h3><a href="http://eecs.berkeley.edu">UC Berkeley EECS</a></h3>
                        <h3>TuTh 8:00-9:30am, <a href="http://www.berkeley.edu/map?wheeler">150 Wheeler</a></h3>
                        <h3>Instructors: <a href="http://bnrg.cs.berkeley.edu/~randy/">Randy Katz</a>, <a href="https://people.eecs.berkeley.edu/~krste/">Krste Asanovic</a></h3>
                        </div>
                    </div>

                    <div class="col-md-6" style="align: right; padding-top:20px" align="right">
                        <div style="height: 200px; overflow: hidden;">        <img src="../../img/P&H.jpg" height="200" class="img-rounded"/> <img src="../../img/WSC.jpg" height="200" class="img-rounded"/> <img src="../../img/K&R.jpg" height="200" class="img-rounded"/></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<div class="container">
    <!-- end include -->



<h1>Contents of lecture/</h1>
<table cellSpacing="2" cellPadding="2" class="table table-bordered table-striped" >
<thead>
<tr><th>Name</th><th>Size</th><th>Last Modified</th></tr>
</thead>
<tbody>

<tr>
<td><a href="01">01</a></td>
<td>0</td>
<td>Thu, 18 Jan 2018 14:39:40 -0800</td>
</tr>
<tr>
<td><a href="02">02</a></td>
<td>0</td>
<td>Thu, 18 Jan 2018 14:39:41 -0800</td>
</tr>
<tr>
<td><a href="index.php">index.php</a></td>
<td>1960</td>
<td>Thu, 18 Jan 2018 14:39:41 -0800</td>
</tr>
<tr>
<td><a href="pagefooter.html">pagefooter.html</a></td>
<td>1609</td>
<td>Thu, 18 Jan 2018 14:39:41 -0800</td>
</tr>
<tr>
<td><a href="pageheader.html">pageheader.html</a></td>
<td>6218</td>
<td>Tue, 06 Mar 2018 13:45:03 -0800</td>
</tr>
<tr>
<td><a href="03">03</a></td>
<td>0</td>
<td>Tue, 23 Jan 2018 11:15:01 -0800</td>
</tr>
<tr>
<td><a href="04">04</a></td>
<td>0</td>
<td>Thu, 25 Jan 2018 11:32:00 -0800</td>
</tr>
<tr>
<td><a href="05">05</a></td>
<td>0</td>
<td>Mon, 29 Jan 2018 17:44:22 -0800</td>
</tr>
<tr>
<td><a href="06">06</a></td>
<td>0</td>
<td>Thu, 01 Feb 2018 09:51:48 -0800</td>
</tr>
<tr>
<td><a href="07">07</a></td>
<td>0</td>
<td>Tue, 06 Feb 2018 08:55:10 -0800</td>
</tr>
<tr>
<td><a href="08">08</a></td>
<td>0</td>
<td>Thu, 08 Feb 2018 12:27:10 -0800</td>
</tr>
<tr>
<td><a href="09">09</a></td>
<td>0</td>
<td>Thu, 15 Feb 2018 15:26:11 -0800</td>
</tr>
<tr>
<td><a href="10">10</a></td>
<td>0</td>
<td>Tue, 20 Feb 2018 15:06:50 -0800</td>
</tr>
<tr>
<td><a href="11">11</a></td>
<td>0</td>
<td>Thu, 22 Feb 2018 12:09:32 -0800</td>
</tr>
<tr>
<td><a href="12">12</a></td>
<td>0</td>
<td>Mon, 26 Feb 2018 14:56:07 -0800</td>
</tr>
<tr>
<td><a href="13">13</a></td>
<td>0</td>
<td>Thu, 01 Mar 2018 14:53:48 -0800</td>
</tr>
<tr>
<td><a href="14">14</a></td>
<td>0</td>
<td>Tue, 06 Mar 2018 13:45:03 -0800</td>
</tr>
<tr>
<td><a href="15">15</a></td>
<td>0</td>
<td>Thu, 08 Mar 2018 12:33:28 -0800</td>
</tr>
<tr>
<td><a href="16">16</a></td>
<td>0</td>
<td>Tue, 13 Mar 2018 15:15:30 -0700</td>
</tr>
<tr>
<td><a href="17">17</a></td>
<td>0</td>
<td>Thu, 15 Mar 2018 09:24:48 -0700</td>
</tr>
<tr>
<td><a href="18">18</a></td>
<td>0</td>
<td>Thu, 22 Mar 2018 15:03:05 -0700</td>
</tr>
<tr>
<td><a href="21">21</a></td>
<td>0</td>
<td>Tue, 03 Apr 2018 15:50:19 -0700</td>
</tr>
<tr>
<td><a href="22">22</a></td>
<td>0</td>
<td>Thu, 05 Apr 2018 15:20:35 -0700</td>
</tr>
<tr>
<td><a href="23">23</a></td>
<td>0</td>
<td>Tue, 10 Apr 2018 14:48:38 -0700</td>
</tr>
<tr>
<td><a href="24">24</a></td>
<td>0</td>
<td>Thu, 12 Apr 2018 15:07:37 -0700</td>
</tr>
<tr>
<td><a href="25">25</a></td>
<td>0</td>
<td>Tue, 17 Apr 2018 13:42:17 -0700</td>
</tr>
<tr>
<td><a href="26">26</a></td>
<td>0</td>
<td>Thu, 19 Apr 2018 15:33:26 -0700</td>
</tr>
<tr>
<td><a href="27">27</a></td>
<td>0</td>
<td>Tue, 24 Apr 2018 13:49:33 -0700</td>
</tr>
<tr>
<td><a href="28">28</a></td>
<td>0</td>
<td>Thu, 26 Apr 2018 14:32:14 -0700</td>
</tr>
</tbody>
</table>



        <div class="row" style="padding-bottom:20px;">
<hr align=left>

<div class="col-md-12">CS61C, <a href="https://eecs.berkeley.edu">Electrical Engineering and Computer Sciences</a>, <a href="http://berkeley.edu">University of California, Berkeley</a> <br> <a href="http://inst.eecs.berkeley.edu/~cs61c/">http://inst.eecs.berkeley.edu/~cs61c/</a>
            </div>

        </div>

    </div> <!-- /container -->


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src='../../fullcalendar/lib/moment.min.js'></script>
    <script src='../../fullcalendar/lib/jquery.min.js'></script>
    <script src='../../fullcalendar/fullcalendar.min.js'></script>
    <script src='../../fullcalendar/gcal.js'></script>
    <script src='../../weekly_schedule.js'></script>
    <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script> -->
    <script src="../../bootstrap-dist/js/bootstrap.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="../../js/ie10-viewport-bug-workaround.js"></script>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-63692984-1', 'auto');
  ga('send', 'pageview');

</script>

<script>
// hacky link fix
q = $("a[id^='na']"); // get all a tags with id starting with na
q.each(function () {
  $(this).attr("href", "./../../" + $(this).attr("href"));
});
//$("#polnavbutton").addClass("active");
</script>

</body>
</html>
