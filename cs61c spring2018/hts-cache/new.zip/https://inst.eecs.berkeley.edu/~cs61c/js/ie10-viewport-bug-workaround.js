<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<html><head>
<title>404 Not Found</title>
</head><body>
<h1>Not Found</h1>
<p>The requested URL /~cs61c/js/ie10-viewport-bug-workaround.js was not found on this server.</p>
<hr>
<address>Apache/2.4.7 (Ubuntu) Server at inst.eecs.berkeley.edu Port 443</address>
</body></html>
